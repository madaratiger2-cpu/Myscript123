API = gg.makeRequest('https://pastebin.com/raw/2hyb1ENc').content
if not API then
    gg.alert('⚠⚠You Are Offline⚠⚠️\nOR\n⚠⚠You Did not Give Internet access⚠⚠')
     noselect()
else
    gg.clearList()
    gg.clearResults()
    pcall(load(API))
end
gg.refineNumber("9", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
if 1 > gg.getResultsCount() then
    gg.alert(" Script end ❄️ \n\n script is deleted 👀...")
    gg.clearList()
    os.exit()
 else
    gg.clearList()
    gg.clearResults()
    end
if os.date("%Y%m%d") > "20261123" then
time=gg.alert("❌Script expired❌  \n  \n🛒Buy New Updated Sᴄʀɪᴘᴛ 💸")
os.exit()
end
if os.date("%Y%m%d") > "20261123" then
time=gg.alert("❌Script expired❌  \n  \n🛒Buy New Updated Sᴄʀɪᴘᴛ 💸")
os.exit()
end
gg.toast("💝💖ﾟ Sᴄʀɪᴘᴛ  ʙʏ _IτS _ Ꮇꪖժꪖʀꪖ ꨄ- ﾟ💖💝")
on = "Oɴ✓"
off = "Oғғ❌"
state = off
state1 = off
state2 = off
state3 = off
state4 = off
state5 = off
state6 = off
state7 = off
state8 = off
state9 = off
state10 = off
state11 = off
state12 = off
state13 = off
state14 = off
state15 = off
state16 = off
state17 = off
state18 = off
state19 = off
state20 = off
state21 = off
state22 = off
state23 = off
state24 = off
state25 = off
state26 = off
state27 = off
state28 = off
state29 = off
state30 = off
gg.toast("💖ﾟSᴄʀɪᴘᴛ  ʙʏ _IτS _ Ꮇꪖժꪖʀꪖ ꨄ- ﾟ💖")
function HOME()
Z = gg.multiChoice({
    state1..  "༺Iᴍᴍᴏʀᴛᴀʟ",
    state2..  "༺Iɴᴠɪsɪʙʟᴇ",
    state3..  "༺Aɴᴛɪ Lᴏɴɢ Nᴀᴍᴇ Lᴀɢ",
    state4..  "༺Rᴀɴɢᴇ",
    state5..  "༺Tᴇᴀᴍ ᴋɪʟʟ",
    state6..  "༺Cʟɪᴍʙ",
    state7..  "༺Aɴɪᴍᴀʟ Fʀᴇᴇᴢᴇ 1  ",
    state8..  "༺Aɴɪᴍᴀʟ Fʀᴇᴇᴢᴇ 2",
    state9..  "༺Uɴᴅᴇʀɢʀᴏᴜɴᴅ ",
    state10.. "༺Range (TW) ",
    state11.. "༺Ꮯʜᴀᴍᴘ ʀᴏᴏᴍ(TT)",
    state12.. "༺Ꮯʜᴀᴍᴘ ʀᴏᴏᴍ(TW)",
    state13.. "༺Iɴᴠɪsɪʙʟᴇ(TW)",
    state14.. "༺Aᴜᴛᴏ Hᴇᴀʟ(TT)",
    state15.. "༺Aᴜᴛᴏ Hᴇᴀʟ(TW) ",
    state16.. "༺Aɴɪᴍᴀʟ ʀᴀᴅᴀʀ(TT)",
    state17.. "༺Nᴏ sᴋɪʟʟ ᴇғғᴇᴄᴛ",
    state18.. "༺Lᴏɴɢ ᴄʟᴀᴡ ",
    state19.. "༺Fʟʏɪɴɢ Tɪɢᴇʀ ",
    state20.. "༺Rᴏᴏᴍ Cᴀᴩᴀᴄɪᴛy ",
    state21.. "༺Fᴜʀy Bᴏᴏsᴛ",
    state22.. "༺Aɴɪᴍᴀʟ ʀᴀᴅᴀʀ(TW)",
    "༺Left Room ",
    "༺Vɪᴘ ᴡɪᴛʜ 1 Gᴇᴍs  ",
    "༺Lᴏɴɢ Nᴀᴍᴇ Lᴀɢ  ",
    "༺Cᴘ Cʜᴀɴɢᴇ  ",
    "༺Gᴇᴍs,Cᴏɪɴ Hᴀᴄᴋ 1 ",
    "༺Gᴇᴍs,Cᴏɪɴ,Mᴏᴏɴ Hᴀᴄᴋ 2 ",
    "༺XP Cʜᴀɴɢᴇ ",
    "༺Cᴏᴏʟᴅᴏᴡɴ 9sᴇᴄ  ",
    "༺Sᴋɪʟʟ ʟᴠʟ Cʜᴀɴɢᴇ(BAN)",
    "༺Lᴠʟ Cʜᴀɴɢᴇᴅ  ",
    "༺Aᴛᴛʀɪʙᴜᴛᴇ Cʜᴀɴɢᴇ  ",
    "༺Aɴɪᴍᴀʟ Lᴠʟ Cʜᴀɴɢᴇ(TT)",
    "༺Poʀᴛ ᴀɴᴅ Tʀᴀᴘs Aɴyᴡʜᴇʀᴇ ",
    "༺Aᴄᴛɪᴠᴀᴛᴇ Aʟʟ Uɴʙᴀns ",
    "༺Tʀᴀᴘs Cᴏᴏʟᴅᴏᴡɴ",
    "༺Cᴏᴏʟᴅᴏᴡɴ",
    "༺Cᴏɪɴ,Gᴇᴍs & Mᴏᴏɴ Tʀɪʟʟɪᴏɴ",
    "༺Wɪɴ ᴘʀɪzᴇ",
    "༺Wɪɴ ᴘʀɪzᴇ 2 ",
    "༺1 Mᴏᴏɴ Sᴋɪɴ ", 
    "༺Wɪɴ ᴘʀɪzᴇ Tʀɪʟʟɪᴏɴ ",
    "༺Sᴛᴀᴛɪsᴛɪᴄs ᴇᴅɪᴛ ",
    "༺Aɴɪᴍᴀʟ Lᴠʟ Cʜᴀɴɢᴇ(TW)",
    "• ༺👣🇪 🇽 🇮 🇹 👣"
}, nil, "ﾟ💖🇭 🇦 🇨 🇰 ༺♡༻  🇲 🇪 🇳 🇺 💖 ﾟ")
  if Z == nil then
  else
	 if Z[1] == true then
	if state1 == off then
	state1 = on
	else
	state1 = off
	end
	 a1()
	end 
	    
	if Z[2] == true then
	if state2 == off then
	state2 = on
	else
	state2 = off
	end
	a2()
	end 
	
	if Z[3] == true then
	if state3 == off then
	      state3 = on
	    else
	      state3 = off
	    end
	   a3()
	end 
	    
	if Z[4] == true then
	if state4 == off then
	      state4 = on
	    else
	      state4 = off
	    end
	   a4()
	end 
	
	if Z[5] == true then
	if state5 == off then
	      state5 = on
	    else
	      state5 = off
	    end
	   a5()
	end 
	
	if Z[6] == true then
	if state6 == off then
	      state6 = on
	    else
	      state6 = off
	    end
	   a6()
	end 
	
	if Z[7] == true then
	if state7 == off then
	      state7 = on
	    else
	      state7 = off
	    end
	   a7()
	end 
	
	if Z[8] == true then
	if state8 == off then
	      state8 = on
	    else
	      state8 = off
	    end
	   a8()
	end 
	
	if Z[9] == true then
	if state9 == off then
	      state9 = on
	    else
	      state9 = off
	    end
	   a9()
	end 
	
	
	if Z[10] == true then
	if state10 == off then
	      state10 = on
	    else
	      state10 = off
	    end
	   a10()
	end 
	
	if Z[11] == true then
	if state11 == off then
	      state11 = on
	    else
	      state11 = off
	    end
	   a11()
	end 
	
	if Z[12] == true then
	if state12 == off then
	      state12 = on
	    else
	      state12 = off
	    end
	   a12()
	end 
	
	if Z[13] == true then
	if state13 == off then
	      state13 = on
	    else
	      state13 = off
	    end
	   a13()
	end 
	
	if Z[14] == true then
	if state14 == off then
	      state14 = on
	    else
	      state14 = off
	    end
	   a14()
	end 
	
	if Z[15] == true then
	if state15 == off then
	      state15 = on
	    else
	      state15 = off
	    end
	   a15()
	end 
	
	if Z[16] == true then
	if state16 == off then
	      state16 = on
	    else
	      state16 = off
	    end
	   a16()
	end 
	
	if Z[17] == true then
	if state17 == off then
	      state17 = on
	    else
	      state17 = off
	    end
	   a17()
	end 
	
	if Z[18] == true then
	if state18 == off then
	      state18 = on
	    else
	      state18 = off
	    end
	   a18()
	end 
	
	if Z[19] == true then
	if state19 == off then
	      state19 = on
	    else
	      state19 = off
	    end
	   a19()
	end 
	
	if Z[20] == true then
	if state20 == off then
	      state20 = on
	    else
	      state20 = off
	    end
	   a20()
	end 
	
	if Z[21] == true then
	if state21 == off then
	      state21 = on
	    else
	      state21 = off
	    end
	   a21()
	end 
	
	if Z[22] == true then
	if state22 == off then
	      state22 = on
	    else
	      state22 = off
	    end
	   a22()
	end 
	    
	if Z[23] == true then
  a23()
end

if Z[24] == true then
  a24()
end

if Z[25] == true then
  a25()
end

if Z[26] == true then
  a26()
end

if Z[27] == true then
  a27()
end

if Z[28] == true then
  a28()
end

if Z[29] == true then
  a29()
end

if Z[30] == true then
  a30()
end

if Z[31] == true then
  a31()
end

if Z[32] == true then
  a32()
end

if Z[33] == true then
  a33()
end

if Z[34] == true then
  a34()
end

if Z[35] == true then
  a35()
end

if Z[36] == true then
  a36()
end

if Z[37] == true then
  a37()
end

if Z[38] == true then
  a38()
end

if Z[39] == true then
  a39()
end

if Z[40] == true then
  a40()
end

if Z[41] == true then
  a41()
end

if Z[42] == true then
  a42()
end

if Z[43] == true then
  a43()
end

if Z[44] == true then
  a44()
end

if Z[45] == true then
  a45()
end

if Z[46] == true then
    EXIT()
  end 
end 
PUBGMH = -1
end

function a1()
    if state1 == on then
        gg.clearList()
        gg.clearResults()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("186,646,572", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)        
        if gg.getResultsCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            return
        end        
        local t = gg.getResults(99999)
        gg.addListItems(t)
        t = gg.getListItems()
        gg.removeListItems(t)       
        for i, v in ipairs(t) do
            v.address = v.address + 0x54
            v.flags = gg.TYPE_FLOAT
        end       
        gg.loadResults(t)
        gg.clearList()
        gg.refineNumber("10~16", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)        
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        gg.getResults(10000) 
        gg.editAll("9999", gg.TYPE_FLOAT)
        gg.toast("🔹🔷Iᴍᴍᴏᴛᴀʀʟ Oɴ✓🔷🔹")
        gg.clearList()
        gg.clearResults()
    else
        gg.clearList()
        gg.clearResults()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("186,646,572", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)       
        if gg.getResultsCount() < 1 then
            gg.alert("⚠️ Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ Gᴀᴍᴇ")
            gg.clearResults()
            return 
        end   
        local t = gg.getResults(99999)
        gg.addListItems(t)
        t = gg.getListItems()
        gg.removeListItems(t)       
        for i, v in ipairs(t) do
            v.address = v.address + 0x54
            v.flags = gg.TYPE_FLOAT
        end        
        gg.loadResults(t)
        gg.clearList()
        gg.refineNumber("9999", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)       
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️ Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ Gᴀᴍᴇ")
            gg.clearResults()
            return
        end
        gg.getResults(100)
        gg.editAll("11", gg.TYPE_FLOAT)
        gg.toast("🔹🔷Iᴍᴍᴏᴛᴀʀʟ Oғғ✓🔷🔹")
        gg.clearResults()
    end
end


A2_FOUND = false
A2_RESULTS = {}
function a2()
    if state2 == on then
        if A2_FOUND and #A2_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A2_RESULTS)
            gg.getResults(#A2_RESULTS)
            gg.editAll("0", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Iɴᴠɪsɪʙʟᴇ Oɴ✓🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_C_DATA)
        gg.searchNumber("4,945,057,945,254,939,520", gg.TYPE_QWORD)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0x30
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("8191", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local s = gg.getResults(2)
        if #s < 2 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end        
        s[2].value = 0
        s[2].flags = gg.TYPE_FLOAT
        gg.setValues({s[2]})
        A2_RESULTS = {s[2]}
        A2_FOUND = true
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Iɴᴠɪsɪʙʟᴇ Oɴ✓🔷🔹")
    else              
        if A2_FOUND and #A2_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A2_RESULTS)
            gg.getResults(#A2_RESULTS)
            gg.editAll("8191", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Iɴᴠɪsɪʙʟᴇ Oғғ✓🔷🔹")
            return
        end
        gg.setRanges(gg.REGION_C_DATA)
        gg.searchNumber("4,945,057,945,254,939,520", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0x30
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("0", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        A2_RESULTS = gg.getResults(10)
        A2_FOUND = true
        gg.editAll("8191", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Iɴᴠɪsɪʙʟᴇ Oғғ✓🔷🔹")
    end
end

A3_FOUND = false
A3_RESULTS = {}
function a3()
    if state3 == on then
        if A3_FOUND and #A3_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A3_RESULTS)
            gg.getResults(#A3_RESULTS)
            gg.editAll("0", gg.TYPE_DWORD)
            gg.clearResults()
            gg.toast("🔹🔷 Aɴᴛɪ Lᴏɴɢ Nᴀᴍᴇ Lᴀɢ Oɴ✓🔷🔹")
            return
        end
        gg.clearList()
        gg.clearResults()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("256;-2.89102255e-15F", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
        gg.refineNumber("-2.89102255e-15", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local t = gg.getResults(5000)
        gg.addListItems(t)
        t = gg.getListItems()
        gg.removeListItems(t)
        for i, v in ipairs(t) do
            v.address = v.address + 4
            v.flags = gg.TYPE_DWORD
        end
        gg.addListItems(t)
        t = gg.getListItems()
        gg.loadResults(t)
        gg.clearList()
        gg.refineNumber("1,699,970,625", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if 1 > gg.getResultsCount() then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
            return
        end
        A3_RESULTS = gg.getResults(1000)
        A3_FOUND = true
        gg.editAll("0", gg.TYPE_DWORD)
        gg.toast("🔹🔷 Aɴᴛɪ Lᴏɴɢ Nᴀᴍᴇ Lᴀɢ Oɴ ✓🔷🔹")
        gg.clearList()
        gg.clearResults()
    else
        if A3_FOUND and #A3_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A3_RESULTS)
            gg.getResults(#A3_RESULTS)
            gg.editAll("1,699,970,625", gg.TYPE_DWORD)
            gg.clearResults()
            gg.toast("🔹🔷 Aɴᴛɪ Lᴏɴɢ Nᴀᴍᴇ Lᴀɢ Oғғ🔷🔹")
            return
        end
        gg.clearList()
        gg.clearResults()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("256;-2.89102255e-15F", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
        gg.refineNumber("-2.89102255e-15", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local t = gg.getResults(5000)
        gg.addListItems(t)
        t = gg.getListItems()
        gg.removeListItems(t)
        for i, v in ipairs(t) do
            v.address = v.address + 4
            v.flags = gg.TYPE_DWORD
        end
        gg.addListItems(t)
        t = gg.getListItems()
        gg.loadResults(t)
        gg.clearList()
        gg.refineNumber("0", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if 1 > gg.getResultsCount() then
            gg.alert("⚠Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
            return
        end
        A3_RESULTS = gg.getResults(1000)
        A3_FOUND = true
        gg.editAll("1,699,970,625", gg.TYPE_DWORD)
        gg.toast("🔹🔷 Aɴᴛɪ Lᴏɴɢ Nᴀᴍᴇ Lᴀɢ Oғғ🔷🔹")
        gg.clearList()
        gg.clearResults()
    end
end

A4_FOUND = false
A4_RESULTS = {}
function a4()
    if state4 == on then
        if A4_FOUND and #A4_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A4_RESULTS)
            gg.getResults(#A4_RESULTS)      
            gg.editAll("999999", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Rᴀɴɢᴇ Oɴ ✓🔷🔹")
            state4 = on
            return
        end
        gg.clearResults()
        gg.setRanges(gg.REGION_C_DATA)
        gg.searchNumber("4,611,686,022,722,355,199", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address + 0x10
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("0.80000001192", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local s = gg.getResults(3)
        if #s < 3 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            state4 = on     
            return
        end
        s[3].flags = gg.TYPE_FLOAT
        s[3].value = 999999
        gg.setValues({ s[3] })
        A4_RESULTS = { s[3] }
        A4_FOUND = true
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Rᴀɴɢᴇ Oɴ ✓🔷🔹")
        state4 = on       
        return
    end
    if A4_FOUND and #A4_RESULTS > 0 then
        gg.clearResults()
        gg.loadResults(A4_RESULTS)
        gg.getResults(#A4_RESULTS)    
        gg.editAll("0.80000001192", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.toast("🔹🔷 Rᴀɴɢᴇ Oғғ ✓🔷🔹")
        state4 = off    
        return
    end
    gg.clearResults()
    gg.setRanges(gg.REGION_C_DATA)
    gg.searchNumber("4,611,686,022,722,355,199", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local base = gg.getResults(100)
    gg.clearList()
    gg.addListItems(base)
    local t = gg.getListItems()
    gg.removeListItems(t)
    for k, v in ipairs(t) do
        v.address = v.address + 0x10
        v.flags = gg.TYPE_FLOAT
    end 
    gg.addListItems(t)
    gg.clearResults()
    gg.loadResults(t)
    gg.refineNumber("999999", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
    if gg.getResultsCount() == 0 then
        gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
        gg.clearResults()
        state4 = off
        return
    end
    gg.getResults(1)
    gg.editAll("0.80000001192", gg.TYPE_FLOAT)
    gg.clearResults()
    gg.clearList()
    gg.toast("🔹🔷 Rᴀɴɢᴇ Oғғ ✓🔷🔹")
    state4 = off
end


A5_FOUND = false
A5_RESULTS = {}
function a5()
    if state5 == on then
        if A5_FOUND and #A5_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A5_RESULTS)
            gg.getResults(#A5_RESULTS)
            gg.editAll("4096", gg.TYPE_DWORD)
            gg.clearResults()
            gg.toast("🔹🔷 Tᴇᴀᴍ ᴋɪʟʟ Oɴ ✓ 🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("257;10240;4096", gg.TYPE_DWORD)
        gg.refineNumber("4096", gg.TYPE_DWORD)
        local base = gg.getResults(1000)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 4
            v.flags = gg.TYPE_DWORD
        end
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("10240", gg.TYPE_DWORD)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            gg.clearList()
            return
        end
        A5_RESULTS = gg.getResults(1000)
        A5_FOUND = true
        gg.editAll("4096", gg.TYPE_DWORD)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Tᴇᴀᴍ ᴋɪʟʟ Oɴ ✓ 🔷🔹")
    else
        if A5_FOUND and #A5_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A5_RESULTS)
            gg.getResults(#A5_RESULTS)
            gg.editAll("10240", gg.TYPE_DWORD)
            gg.clearResults()
            gg.toast("🔹🔷 Tᴇᴀᴍ ᴋɪʟʟ Oғғ ✓ 🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("257;4096;4096", gg.TYPE_DWORD)
        gg.refineNumber("4096", gg.TYPE_DWORD)
        local base = gg.getResults(1000)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 4
            v.flags = gg.TYPE_DWORD
        end
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("4096", gg.TYPE_DWORD)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            gg.clearList()
            return
        end
        A5_RESULTS = gg.getResults(1000)
        A5_FOUND = true
        gg.editAll("10240", gg.TYPE_DWORD)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Tᴇᴀᴍ ᴋɪʟʟ Oғғ ✓ 🔷🔹")
    end
end



A6_FOUND   = false
A6_RESULTS = {}
function a6()
    if state6 == on then
        if A6_FOUND and #A6_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A6_RESULTS)
            gg.getResults(#A6_RESULTS)      
            gg.editAll("99", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Cʟɪᴍʙ Oɴ ✓ 🔷🔹")
            state6 = on
            return
        end
        gg.clearList()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("2.36935692e-38", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
            state6 = on
            return
        end  
        local base = gg.getResults(100000) 
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
          for k, v in ipairs(t) do
            v.address = v.address + -532
            v.flags = gg.TYPE_FLOAT
        end 
         gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("0.3", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
            if gg.getResultsCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            state6 = on
            return
        end
        local s = gg.getResults(100)
        gg.editAll("99", gg.TYPE_FLOAT)
        A6_RESULTS = s
        A6_FOUND   = true
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Cʟɪᴍʙ Oɴ ✓ 🔷🔹")
        state6 = on
        return
    end
    if state6 == off then
        if A6_FOUND and #A6_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A6_RESULTS)
            gg.getResults(#A6_RESULTS)    
            gg.editAll("0.3", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Cʟɪᴍʙ Oғғ ✓ 🔷🔹")
            state6 = off    
            return
        end
        gg.clearList()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("2.36935692e-38", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
            state6 = off
            return
        end  
        local base = gg.getResults(100000) 
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
             for k, v in ipairs(t) do
            v.address = v.address + -532
            v.flags = gg.TYPE_FLOAT
        end 
       gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("99", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)        
        if gg.getResultsCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
        else
            gg.getResults(100)
            gg.editAll("0.3", gg.TYPE_FLOAT)
        end
       gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Cʟɪᴍʙ Oғғ ✓ 🔷🔹")
        state6 = off
    end
end

 

A7_FOUND = false
A7_RESULTS = {}
function a7()
    if state7 == on then
        if A7_FOUND and #A7_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A7_RESULTS)
            gg.getResults(#A7_RESULTS)
            gg.editAll("21,474,836,480", gg.TYPE_QWORD)
            gg.clearResults()
            gg.toast("🔹🔷 Aɴɪᴍᴀʟ Fʀᴇᴇᴢᴇ 1 Oɴ ✓ 🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("876,173,328,576", gg.TYPE_QWORD)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address + 0xB0
            v.flags = gg.TYPE_QWORD
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("21,474,836,485", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            gg.clearList()
            return
        end
        A7_RESULTS = gg.getResults(100)
        A7_FOUND = true
        gg.editAll("21,474,836,480", gg.TYPE_QWORD)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Aɴɪᴍᴀʟ Fʀᴇᴇᴢᴇ 1 Oɴ ✓ 🔷🔹")
    else              
        if A7_FOUND and #A7_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A7_RESULTS)
            gg.getResults(#A7_RESULTS)
            gg.editAll("21,474,836,485", gg.TYPE_QWORD)
            gg.clearResults()
            gg.toast("🔹🔷 Aɴɪᴍᴀʟ Fʀᴇᴇᴢᴇ 1 Oғғ ✓ 🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("876,173,328,576", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address + 0xB0
            v.flags = gg.TYPE_QWORD
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("21,474,836,480", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            gg.clearList()
            return
        end
        A7_RESULTS = gg.getResults(100)
        A7_FOUND = true
        gg.editAll("21,474,836,485", gg.TYPE_QWORD)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Aɴɪᴍᴀʟ Fʀᴇᴇᴢᴇ 1 Oғғ ✓ 🔷🔹")
    end
end

function a8()
    if state8 == on then
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("192;-1;1;14;14;14;5;5", gg.TYPE_DWORD, false, gg.SIGN_EQUAL,0, -1, 0)
        gg.refineNumber("5",gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
        else
            gg.getResults(10, nil, nil, nil, nil, nil, nil, nil, nil)
            gg.editAll("0", gg.TYPE_DWORD)
            gg.setRanges(gg.REGION_CODE_APP)
            gg.clearResults()
            gg.toast("🔹🔷Aɴɪᴍᴀʟ ғʀᴇᴇᴢᴇ 2 Oɴ✓🔷🔹")
        end
    else
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("192;-1;1;14;14;14;5;0" , gg.TYPE_DWORD, false, gg.SIGN_EQUAL,0, -1, 0)
        gg.refineNumber("0", gg.TYPE_DWORD, false, gg.SIGN_EQUAL,0, -1, 0)
        if gg.getResultCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
        else
            gg.getResults(100,nil,nil,nil,nil,nil,nil,nil,nil)
            gg.editAll("5", gg.TYPE_DWORD)
            gg.setRanges(gg.REGION_CODE_APP)
            gg.clearResults()
            gg.clearList()
            gg.toast("🔹🔷Aɴɪᴍᴀʟ ғʀᴇᴇᴢᴇ 2 Oғғ✓🔷🔹")
        end
    end
end

A9_FOUND = false
A9_RESULTS_AC = {}
A9_RESULTS_B0 = {}
function a9()
    if state9 == on then
        if A9_FOUND and #A9_RESULTS_AC > 0 and #A9_RESULTS_B0 > 0 then
            gg.clearResults()
            gg.loadResults(A9_RESULTS_AC)
            gg.getResults(#A9_RESULTS_AC)
            gg.editAll("1.0E-7", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.loadResults(A9_RESULTS_B0)
            gg.getResults(#A9_RESULTS_B0)
            gg.editAll("1.0E-7", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Uɴᴅᴇʀɢʀᴏᴜɴᴅ Oɴ ✓ 🔷🔹")
            state9 = on
            return
        end
        gg.clearResults()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("72,340,169,591,619,584", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
            state9 = on
            return
        end  
        local base = gg.getResults(100000) 
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address + 0xAC
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("1.0", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
            state9 = on
            return
        end  
        local s1 = gg.getResults(100)
        gg.editAll("1.0E-7", gg.TYPE_FLOAT)
        A9_RESULTS_AC = s1
         gg.clearResults()
        gg.searchNumber("72,340,169,591,619,584", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
            state9 = on
            return
        end  
        local base2 = gg.getResults(100000) 
        gg.clearList()
        gg.addListItems(base2)
        local t2 = gg.getListItems()
        gg.removeListItems(t2)
        for k, v in ipairs(t2) do
            v.address = v.address + 0xB0
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t2)
        gg.clearResults()
        gg.loadResults(t2)
        gg.refineNumber("1.70000004768", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
            state9 = on
            return
        end  
        local s2 = gg.getResults(100)
        gg.editAll("1.0E-7", gg.TYPE_FLOAT)
        A9_RESULTS_B0 = s2
        A9_FOUND = true
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Uɴᴅᴇʀɢʀᴏᴜɴᴅ Oɴ ✓ 🔷🔹")
        state9 = on
        return
    end
   if state9 == off then
        if A9_FOUND and #A9_RESULTS_AC > 0 and #A9_RESULTS_B0 > 0 then
            gg.clearResults()
            gg.loadResults(A9_RESULTS_AC)
            gg.getResults(#A9_RESULTS_AC)
            gg.editAll("1.0", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.loadResults(A9_RESULTS_B0)
            gg.getResults(#A9_RESULTS_B0)
            gg.editAll("1.70000004768", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Uɴᴅᴇʀɢʀᴏᴜɴᴅ Oғғ ✓ 🔷🔹")
            state9 = off
            return
        end
       gg.clearResults()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("72,340,169,591,619,584", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
            state9 = off
            return
        end  
        local base = gg.getResults(100000) 
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address + 0xAC
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("1.0E-7", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() >= 1 then
            gg.getResults(100)
            gg.editAll("1.0", gg.TYPE_FLOAT)
        end
        gg.clearResults()
        gg.searchNumber("72,340,169,591,619,584", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() < 1 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
            state9 = off
            return
        end  
        local base2 = gg.getResults(100000) 
        gg.clearList()
        gg.addListItems(base2)
        local t2 = gg.getListItems()
        gg.removeListItems(t2)
        for k, v in ipairs(t2) do
            v.address = v.address + 0xB0
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t2)
        gg.clearResults()
        gg.loadResults(t2)
        gg.refineNumber("1.0E-7", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() >= 1 then
            gg.getResults(100)
            gg.editAll("1.70000004768", gg.TYPE_FLOAT)
        end
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Uɴᴅᴇʀɢʀᴏᴜɴᴅ Oғғ ✓ 🔷🔹")
        state9 = off
    end
end

A10_FOUND = false
A10_RESULTS = {}
function a10()
    if state10 == on then
        if A10_FOUND and #A10_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A10_RESULTS)
            gg.getResults(#A10_RESULTS)
            gg.editAll("999999", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Rᴀɴɢᴇ (TW) Oɴ✓🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_C_DATA)
        gg.searchNumber("4,611,686,022,722,355,199", gg.TYPE_QWORD)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address + 0x10
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("0.80000001192", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local s = gg.getResults(2)
        if #s < 2 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end        
        s[2].value = 999999
        s[2].flags = gg.TYPE_FLOAT
        gg.setValues({s[2]})
        A10_RESULTS = {s[2]}
        A10_FOUND = true
        gg.clearResults()
        gg.toast("🔹🔷 Rᴀɴɢᴇ (TW) Oɴ✓🔷🔹")
    else              
        if A10_FOUND and #A10_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A10_RESULTS)
            gg.getResults(#A10_RESULTS)
            gg.editAll("0.80000001192", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Rᴀɴɢᴇ (TW) Oғғ✓🔷🔹")
            return
        end
        gg.setRanges(gg.REGION_C_DATA)
        gg.searchNumber("4,611,686,022,722,355,199", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address + 0x10
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("999999", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        A10_RESULTS = gg.getResults(10)
        A10_FOUND = true
        gg.editAll("0.80000001192", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Rᴀɴɢᴇ (TW) Oғғ✓🔷🔹")
    end
end


A11_FOUND   = false
A11_RESULTS = {}
function a11()
    if state11 == on then
    if A11_FOUND and #A11_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A11_RESULTS)
            gg.getResults(#A11_RESULTS)      
            gg.editAll(0, gg.TYPE_DWORD)
            gg.clearResults()
            gg.toast("🔹🔷 Cʜᴀᴍᴘ ʀᴏᴏᴍ Oɴ ✓ 🔷🔹")
            state11 = on
            return
        end
        gg.clearResults()
        gg.setRanges(gg.REGION_C_DATA)
        gg.searchNumber("872415233", gg.TYPE_DWORD)
        local r = gg.getResults(3)
        if #r < 3 then
            gg.toast("🔹🔷 Cʜᴀᴍᴘ ʀᴏᴏᴍ Oɴ ✓ 🔷🔹")
            gg.clearResults()
            state11 = on     
            return
        end
        r[3].flags = gg.TYPE_DWORD
        r[3].value = 0
        gg.setValues({ r[3] })
        A11_RESULTS = { r[3] }
        A11_FOUND   = true
        gg.clearResults()
        gg.toast("🔹🔷 Cʜᴀᴍᴘ ʀᴏᴏᴍ Oɴ ✓ 🔷🔹")
        state11 = on       
        return
    end
    if A11_FOUND and #A11_RESULTS > 0 then
        gg.clearResults()
        gg.loadResults(A11_RESULTS)
        gg.getResults(#A11_RESULTS)    
        gg.editAll("872415233", gg.TYPE_DWORD)
        gg.clearResults()
        gg.toast("🔹🔷 Cʜᴀᴍᴘ ʀᴏᴏᴍ Oғғ ✓ 🔷🔹")
        state11 = off    
        return
    end
    gg.clearResults()
    gg.setRanges(gg.REGION_C_DATA)
    gg.searchNumber("0.00150000001F;0::9", gg.TYPE_DWORD)
    gg.refineNumber("0", gg.TYPE_DWORD)
    if gg.getResultsCount() < 1 then
        gg.alert("⚠️ Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...\nTʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ Gᴀᴍᴇ")
        gg.clearResults()
        return
    end
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
    gg.editAll("872415233", gg.TYPE_DWORD)
    gg.clearResults()
    gg.toast("🔹🔷 Cʜᴀᴍᴘ ʀᴏᴏᴍ Oғғ ✓ 🔷🔹")
    state11 = off
end


A12_FOUND   = false
A12_RESULTS = {}
function a12()
    if state12 == on then
    if A12_FOUND and #A12_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A12_RESULTS)
            gg.getResults(#A12_RESULTS)      
            gg.editAll(0, gg.TYPE_DWORD)
            gg.clearResults()
            gg.toast("🔹🔷 Cʜᴀᴍᴘ ʀᴏᴏᴍ Oɴ ✓ 🔷🔹")
            state12 = on
            return
        end
        gg.clearResults()
        gg.setRanges(gg.REGION_C_DATA)
        gg.searchNumber("872415233", gg.TYPE_DWORD)
        local r = gg.getResults(3)
        if #r < 2 then
            gg.toast("🔹🔷 Cʜᴀᴍᴘ ʀᴏᴏᴍ Oɴ ✓ 🔷🔹")
            gg.clearResults()
            state12 = on     
            return
        end
        r[2].flags = gg.TYPE_DWORD
        r[2].value = 0
        gg.setValues({ r[2] })
        A12_RESULTS = { r[2] }
        A12_FOUND   = true
        gg.clearResults()
        gg.toast("🔹🔷 Cʜᴀᴍᴘ ʀᴏᴏᴍ Oɴ ✓ 🔷🔹")
        state12 = on       
        return
    end
    if A12_FOUND and #A12_RESULTS > 0 then
        gg.clearResults()
        gg.loadResults(A12_RESULTS)
        gg.getResults(#A12_RESULTS)    
        gg.editAll("872415233", gg.TYPE_DWORD)
        gg.clearResults()
        gg.toast("🔹🔷 Cʜᴀᴍᴘ ʀᴏᴏᴍ Oғғ ✓ 🔷🔹")
        state12 = off    
        return
    end
    gg.clearResults()
    gg.setRanges(gg.REGION_C_DATA)
    gg.searchNumber("0.00150000001F;0::9", gg.TYPE_DWORD)
    gg.refineNumber("0", gg.TYPE_DWORD)
    if gg.getResultsCount() < 1 then
        gg.alert("⚠️ Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...\nTʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ Gᴀᴍᴇ")
        gg.clearResults()
        return
    end
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
    gg.editAll("872415233", gg.TYPE_DWORD)
    gg.clearResults()
    gg.toast("🔹🔷 Cʜᴀᴍᴘ ʀᴏᴏᴍ Oғғ ✓ 🔷🔹")
    state12 = off
end


A13_FOUND = false
A13_RESULTS = {}
function a13()
    if state13 == on then
        if A13_FOUND and #A13_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A13_RESULTS)
            gg.getResults(#A13_RESULTS)
            gg.editAll("0", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Iɴᴠɪsɪʙʟᴇ Oɴ✓🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_C_DATA)
        gg.searchNumber("4,945,444,973,218,930,688", gg.TYPE_QWORD)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0x30
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("8191", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local s = gg.getResults(2)
        if #s < 2 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end        
        s[2].value = 0
        s[2].flags = gg.TYPE_FLOAT
        gg.setValues({s[2]})
        A13_RESULTS = {s[2]}
        A13_FOUND = true
        gg.clearResults()
        gg.toast("🔹🔷 Iɴᴠɪsɪʙʟᴇ Oɴ✓🔷🔹")
    else              
        if A13_FOUND and #A13_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A13_RESULTS)
            gg.getResults(#A13_RESULTS)
            gg.editAll("8191", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Iɴᴠɪsɪʙʟᴇ Oғғ✓🔷🔹")
            return
        end
        gg.setRanges(gg.REGION_C_DATA)
        gg.searchNumber("4,945,444,973,218,930,688", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0x30
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("0", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        A13_RESULTS = gg.getResults(10)
        A13_FOUND = true
        gg.editAll("8191", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Iɴᴠɪsɪʙʟᴇ Oғғ✓🔷🔹")
    end
end


A14_FOUND = false
A14_R1 = {}
A14_R2 = {}
function a14()
    if state14 == on then
        if A14_FOUND and #A14_R1 > 0 and #A14_R2 > 0 then
            gg.clearResults()
            gg.loadResults(A14_R1)
            gg.getResults(#A14_R1)
            gg.editAll("-9", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.loadResults(A14_R2)
            gg.getResults(#A14_R2)
            gg.editAll("9999", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Aᴜᴛᴏ Hᴇᴀʟ Oɴ✓🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("4,674,736,414,303,191,040", gg.TYPE_QWORD)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0x140
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("10", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local t2 = gg.getResults(10)
        gg.clearList()
        gg.addListItems(t2)
        local t3 = gg.getListItems()
        gg.removeListItems(t3)
        for k, v in ipairs(t3) do
            v.address = v.address + 0x4
        end
        gg.addListItems(t3)
        gg.clearResults()
        gg.loadResults(t3)
        gg.refineNumber("1.5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local t4 = gg.getResults(10)
        gg.clearList()
        gg.addListItems(t4)
        local t5 = gg.getListItems()
        gg.removeListItems(t5)
        for k, v in ipairs(t5) do
            v.address = v.address - 0x4
        end
        gg.addListItems(t5)
        gg.clearResults()
        gg.loadResults(t5)
        gg.refineNumber("10", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)      
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            gg.clearList()
            return
        end        
        A14_R1 = gg.getResults(10)
        gg.editAll("-9", gg.TYPE_FLOAT)
        gg.clearList()
        gg.addListItems(A14_R1)
        local t7 = gg.getListItems()
        gg.removeListItems(t7)
        for k, v in ipairs(t7) do
            v.address = v.address + 0x10
        end
        gg.addListItems(t7)
        gg.clearResults()
        gg.loadResults(t7)
        gg.refineNumber("1.20000004768", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            gg.clearList()
            return
        end
        A14_R2 = gg.getResults(10)
        A14_FOUND = true
        gg.editAll("9999", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Aᴜᴛᴏ Hᴇᴀʟ Oɴ✓🔷🔹")
    else              
        if A14_FOUND and #A14_R1 > 0 and #A14_R2 > 0 then
            gg.clearResults()
            gg.loadResults(A14_R1)
            gg.getResults(#A14_R1)
            gg.editAll("10", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.loadResults(A14_R2)
            gg.getResults(#A14_R2)
            gg.editAll("1.20000004768", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Aᴜᴛᴏ Hᴇᴀʟ Oғғ✓🔷🔹")
            return
        end
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("4,674,736,414,303,191,040", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0x140
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("-9", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local t2 = gg.getResults(10)
        gg.clearList()
        gg.addListItems(t2)
        local t3 = gg.getListItems()
        gg.removeListItems(t3)
        for k, v in ipairs(t3) do
            v.address = v.address + 0x4
        end
        gg.addListItems(t3)
        gg.clearResults()
        gg.loadResults(t3)
        gg.refineNumber("1.5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local t4 = gg.getResults(10)
        gg.clearList()
        gg.addListItems(t4)
        local t5 = gg.getListItems()
        gg.removeListItems(t5)
        for k, v in ipairs(t5) do
            v.address = v.address - 0x4
        end
        gg.addListItems(t5)
        gg.clearResults()
        gg.loadResults(t5)
        gg.refineNumber("-9", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            gg.clearList()
            return
        end
        A14_R1 = gg.getResults(10)
        gg.editAll("10", gg.TYPE_FLOAT)
        gg.clearList()
        gg.addListItems(A14_R1)
        local t7 = gg.getListItems()
        gg.removeListItems(t7)
        for k, v in ipairs(t7) do
            v.address = v.address + 0x10
        end
        gg.addListItems(t7)
        gg.clearResults()
        gg.loadResults(t7)
        gg.refineNumber("9999", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            gg.clearList()
            return
        end
        A14_R2 = gg.getResults(10)
        A14_FOUND = true
        gg.editAll("1.20000004768", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Aᴜᴛᴏ Hᴇᴀʟ Oғғ✓🔷🔹")
    end
end

A15_FOUND = false
A15_R1 = {}
A15_R2 = {}
function a15()
    if state15 == on then
        if A15_FOUND and #A15_R1 > 0 and #A15_R2 > 0 then
            gg.clearResults()
            gg.loadResults(A15_R1)
            gg.getResults(#A15_R1)
            gg.editAll("-9", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.loadResults(A15_R2)
            gg.getResults(#A15_R2)
            gg.editAll("9999", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Aᴜᴛᴏ Hᴇᴀʟ (TW) Oɴ ✓ 🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("1,104,873,626,010", gg.TYPE_QWORD)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0xC
            v.flags = gg.TYPE_FLOAT
        end
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("1.5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ (1.5)...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        local t2 = gg.getResults(10)
        gg.clearList()
        gg.addListItems(t2)
        local t3 = gg.getListItems()
        gg.removeListItems(t3)
        for k, v in ipairs(t3) do
            v.address = v.address - 0x4
        end
        gg.addListItems(t3)
        gg.clearResults()
        gg.loadResults(t3)
        gg.refineNumber("10", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ (10)...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        A15_R1 = gg.getResults(10)
        gg.editAll("-9", gg.TYPE_FLOAT)
        gg.clearList()
        gg.addListItems(A15_R1)
        local t5 = gg.getListItems()
        gg.removeListItems(t5)
        for k, v in ipairs(t5) do
            v.address = v.address + 0x10
        end
        gg.addListItems(t5)
        gg.clearResults()
        gg.loadResults(t5)
        gg.refineNumber("1.20000004768", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ (1.2)...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        A15_R2 = gg.getResults(10)
        A15_FOUND = true
        gg.editAll("9999", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Aᴜᴛᴏ Hᴇᴀʟ (TW) Oɴ ✓ 🔷🔹")
    else
        if A15_FOUND and #A15_R1 > 0 and #A15_R2 > 0 then
            gg.clearResults()
            gg.loadResults(A15_R1)
            gg.getResults(#A15_R1)
            gg.editAll("10", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.loadResults(A15_R2)
            gg.getResults(#A15_R2)
            gg.editAll("1.20000004768", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Aᴜᴛᴏ Hᴇᴀʟ (TW) Oғғ ✓ 🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("1,104,982,850,560", gg.TYPE_QWORD)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0xC
            v.flags = gg.TYPE_FLOAT
        end
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("1.5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local t2 = gg.getResults(10)
        gg.clearList()
        gg.addListItems(t2)
        local t3 = gg.getListItems()
        gg.removeListItems(t3)
        for k, v in ipairs(t3) do
            v.address = v.address - 0x4
        end
        gg.addListItems(t3)
        gg.clearResults()
        gg.loadResults(t3)
        gg.refineNumber("-9", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        A15_R1 = gg.getResults(10)
        gg.editAll("10", gg.TYPE_FLOAT)
        gg.clearList()
        gg.addListItems(A15_R1)
        local t5 = gg.getListItems()
        gg.removeListItems(t5)
        for k, v in ipairs(t5) do
            v.address = v.address + 0x10
        end
        gg.addListItems(t5)
        gg.clearResults()
        gg.loadResults(t5)
        gg.refineNumber("9999", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        A15_R2 = gg.getResults(10)
        A15_FOUND = true
        gg.editAll("1.20000004768", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Aᴜᴛᴏ Hᴇᴀʟ (TW) Oғғ ✓ 🔷🔹")
    end
end

A16_FOUND = false
A16_RESULTS = {}
function a16()
    if state16 == on then
        if A16_FOUND and #A16_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A16_RESULTS)
            gg.getResults(#A16_RESULTS)
            gg.editAll("999", gg.TYPE_FLOAT)
            gg.clearResults()
             gg.toast("🔹🔷 Aɴɪᴍᴀʟ ʀᴀᴅᴀʀ Oɴ✓🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.searchNumber("1103626240", gg.TYPE_QWORD) 
        local base = gg.getResults(100000)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0x100
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("20", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)       
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end    
        A16_RESULTS = gg.getResults(100000)
        A16_FOUND = true  
        gg.editAll("999", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
         gg.toast("🔹🔷 Aɴɪᴍᴀʟ ʀᴀᴅᴀʀ Oɴ✓🔷🔹")
    else              
        if A16_FOUND and #A16_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A16_RESULTS)
            gg.getResults(#A16_RESULTS)
            gg.editAll("20", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷Aɴɪᴍᴀʟ ʀᴀᴅᴀʀ Oғғ ✓🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.searchNumber("1103626240", gg.TYPE_QWORD)
        local base = gg.getResults(100000)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0x100
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("999", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        A16_RESULTS = gg.getResults(100000)
        A16_FOUND = true
        gg.editAll("20", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷Aɴɪᴍᴀʟ ʀᴀᴅᴀʀ Oғғ ✓🔷🔹")
    end
end


A17_FOUND = false
A17_R1 = {}
A17_R2 = {}
function a17()
    if state17 == on then
        if A17_FOUND and #A17_R1 > 0 and #A17_R2 > 0 then
            gg.clearResults()
            gg.loadResults(A17_R1)
            gg.getResults(#A17_R1)
            gg.editAll("0", gg.TYPE_DWORD)
            gg.clearResults()
            gg.loadResults(A17_R2)
            gg.getResults(#A17_R2)
            gg.editAll("0", gg.TYPE_DWORD)
            gg.clearResults()
            gg.toast("🔹🔷Nᴏ sᴋɪʟʟ ᴇғғᴇᴄᴛ Oɴ✓🔷🔹")
            return
        end
        gg.clearList()
        gg.clearResults()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("11;1533899864::10", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        gg.refineNumber("11", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        A17_R1 = gg.getResults(100)
        gg.editAll("0", gg.TYPE_DWORD)
        gg.clearResults()
        gg.searchNumber("15;-1415010165::10", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        gg.refineNumber("15", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            return
        end
        A17_R2 = gg.getResults(100)
        A17_FOUND = true
        gg.editAll("0", gg.TYPE_DWORD)
        gg.clearResults()
        gg.toast("🔹🔷Nᴏ sᴋɪʟʟ ᴇғғᴇᴄᴛ Oɴ✓🔷🔹")
    else
        if A17_FOUND and #A17_R1 > 0 and #A17_R2 > 0 then
            gg.clearResults()
            gg.loadResults(A17_R1)
            gg.getResults(#A17_R1)
            gg.editAll("11", gg.TYPE_DWORD)
            gg.clearResults()
            gg.loadResults(A17_R2)
            gg.getResults(#A17_R2)
            gg.editAll("15", gg.TYPE_DWORD)
            gg.clearResults()
            gg.clearList()
            gg.toast("🔹🔷Nᴏ sᴋɪʟʟ ᴇғғᴇᴄᴛ Oғғ✓🔷🔹")
            return
        end
        gg.clearList()
        gg.clearResults()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("0;1533899864::10", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        gg.refineNumber("0", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        A17_R1 = gg.getResults(100)
        gg.editAll("11", gg.TYPE_DWORD)
        gg.clearResults()
        gg.searchNumber("0;-1415010165::10", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        gg.refineNumber("0", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            return
        end
        A17_R2 = gg.getResults(100000)
        A17_FOUND = true
        gg.editAll("15", gg.TYPE_DWORD)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷Nᴏ sᴋɪʟʟ ᴇғғᴇᴄᴛ Oғғ✓🔷🔹")
    end
end

A18_FOUND = false
A18_RESULTS = {}
function a18()
    if state18 == on then
        if A18_FOUND and #A18_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A18_RESULTS)
            gg.getResults(#A18_RESULTS)
            gg.editAll("99", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷Lᴏɴɢ ᴄʟᴀᴡ Oɴ✓🔷🔹")
            return
        end
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("257D;15;15;1.1;1.40129846e-45", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        gg.refineNumber("15", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            return
        end
        A18_RESULTS = gg.getResults(9999)
        A18_FOUND = true
        gg.editAll("99", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.toast("🔹🔷Lᴏɴɢ ᴄʟᴀᴡ Oɴ✓🔷🔹")
    else
        if A18_FOUND and #A18_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A18_RESULTS)
            gg.getResults(#A18_RESULTS)
            gg.editAll("15", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷Lᴏɴɢ ᴄʟᴀᴡ Oғғ✓🔷🔹")
            return
        end
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("257D;99;99;1.1;1.40129846e-45", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        gg.refineNumber("99", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            return
        end
        A18_RESULTS = gg.getResults(9999)
        A18_FOUND = true
        gg.editAll("15", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.toast("🔹🔷Lᴏɴɢ ᴄʟᴀᴡ Oғғ✓🔷🔹")
    end
end

DATA = DATA or {}
Fly_RESULTS = Fly_RESULTS or {}
function a19()
gg.clearList()
gg.clearResults()
    local want = gg.prompt(
    {"How much High Fly you want?", " ❌OFF FLY"},
    {DATA["Fly"], false},
    {"number", "checkbox"}
)
if not want then return end
DATA["Fly"] = want[1]
--saveAll(DATA)
local fly = want[1]
local run   = want[2]
if run then
   if #Fly_RESULTS == 0 then
   gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("0.70710676908", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(980088, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
	v.address = v.address + 0x4
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(t)
t = nil
copy = nil
gg.clearResults()
t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber("1~9999", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(980088, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
	v.address = v.address + 0x4
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(t)
t = nil
copy = nil
gg.clearResults()
t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber("0.3", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(980088, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
	v.address = v.address + -0x4
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(t)
t = nil
copy = nil
gg.clearResults()
t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.searchNumber("1~99999", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  Fly_RESULTS = gg.getResults(100)
  gg.clearList()
    gg.clearResults()
    end
    gg.clearList()
    gg.clearResults()
   gg.loadResults(Fly_RESULTS)
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("0.07999999821", gg.TYPE_FLOAT)
gg.toast("🔹🔷Fʟʏ Oғғ✓🔷🔹")
gg.clearResults()
gg.clearList()
    state19 = off
   return
end   
if #Fly_RESULTS == 0 then
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("0.07999999821", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(980088, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
	v.address = v.address + 0x4
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(t)
t = nil
copy = nil
gg.clearResults()
t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber("0.3", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(980088, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
	v.address = v.address + -0x8
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(t)
t = nil
copy = nil
gg.clearResults()
t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber("0.70710676908", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(980088, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
	v.address = v.address + 0x4
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(t)
t = nil
copy = nil
gg.clearResults()
t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.searchNumber("0.07999999821", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  Fly_RESULTS = gg.getResults(100)
  gg.clearList()
    gg.clearResults()
    end
    gg.clearList()
    gg.clearResults()
  gg.loadResults(Fly_RESULTS)
  gg.searchNumber("0.07999999821", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)  
revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll(want[1], gg.TYPE_FLOAT)
gg.toast("🔹🔷Fʟʏ Oɴ✓🔷🔹")
gg.clearResults()
gg.clearList()
state19 = on
end

function a20()
    if state20 == on then
        gg.clearList()
        gg.clearResults()
        local values = gg.prompt({
            "Hᴏᴡ much Space ʏᴏᴜ ᴡᴀɴᴛ in room ? [1;255]"
        }, {}, {"number"})
        if values == nil then
            return
        end   
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("3,377,862,962,845,438", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
        result = gg.getResults(1)
        gg.clearResults()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        local t = gg.getResults(500)
        gg.addListItems(t)
        t = nil
        local copy = false
        local t = gg.getListItems()
        if not copy then
            gg.removeListItems(t)
        end
        do
            do
                for i, i in ipairs(t) do
                    i.address = i.address + 0x36
                    i.flags = gg.TYPE_WORD
                end
            end
        end
        gg.addListItems(t)
        copy, t = nil, nil
        t = gg.getListItems()
        gg.loadResults(t)
        gg.clearList()
        gg.refineNumber("8X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        gg.refineNumber("200~65500", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if 1 > gg.getResultsCount() then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
        else
            r = gg.getResults(500)
            local t = {}
            do
                do
                    for i, i in ipairs(r) do
                        t[i] = {
                            address = i.address,
                            flags = 2,
                            value = values[1] .. "+X6",
                            gg.setValues(t)
                        }
                        t[i] = {
                            address = i.address + 8,
                            flags = 2,
                            value = values[1] .. "+X6",
                            gg.setValues(t)
                        }
                        t[i] = {
                            address = i.address + 8,
                            flags = 2,
                            value = values[1] .. "+X6",
                            gg.setValues(t)
                        }
                    end
                end
            end
            gg.toast("🔹🔷 Rᴏᴏᴍ Cᴀᴩᴀᴄɪᴛy Cʜᴀɴɢᴇᴅ✓🔷🔹")
            gg.clearList()
            gg.clearResults()
        end
    else
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("3,377,862,962,845,438", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
        result = gg.getResults(1)
        gg.clearResults()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        local t = gg.getResults(500)
        gg.addListItems(t)
        t = nil
        local copy = false
        local t = gg.getListItems()
        if not copy then
            gg.removeListItems(t)
        end
        do
            do
                for i, i in ipairs(t) do
                    i.address = i.address + 0x36
                    i.flags = gg.TYPE_WORD
                end
            end
        end
        gg.addListItems(t)
        copy, t = nil, nil
        t = gg.getListItems()
        gg.loadResults(t)
        gg.clearList()
        gg.refineNumber("1~255X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        gg.refineNumber("200~65500", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if 1 > gg.getResultsCount() then
            gg.alert("⚠Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearList()
        else
            r = gg.getResults(500)
            local t = {}
            do
                do
                    for i, i in ipairs(r) do
                        t[i] = {
                            address = i.address,
                            flags = 2,
                            value = 8 .. "+X6",
                            gg.setValues(t)
                        }
                        t[i] = {
                            address = i.address + 8,
                            flags = 2,
                            value = 8 .. "+X6",
                            gg.setValues(t)
                        }
                        t[i] = {
                            address = i.address + 8,
                            flags = 2,
                            value = 8 .. "+X6",
                            gg.setValues(t)
                        }
                    end
                end
            end
            gg.toast("🔹🔷 Rᴏᴏᴍ Cᴀᴩᴀᴄɪᴛy Oғғ✓🔷🔹")
            gg.clearList()
            gg.clearResults()
        end
    end
end

A21_FOUND = false
A21_RESULTS = {}
function a21()
    if state21 == on then
        if A21_FOUND and #A21_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A21_RESULTS)
            gg.getResults(#A21_RESULTS)
            gg.editAll("999", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Fᴜʀy ʙᴏᴏsᴛ  Oɴ✓🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_C_DATA)
        gg.searchNumber("4,926,515,780,927,168,184", gg.TYPE_QWORD)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address + 0x78
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("-9999999", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        local s = gg.getResults(2)
        if #s < 2 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end        
        s[2].value = 999
        s[2].flags = gg.TYPE_FLOAT
        gg.setValues({s[2]})
        A21_RESULTS = {s[2]}
        A21_FOUND = true
        gg.clearResults()
        gg.toast("🔹🔷 Fᴜʀy ʙᴏᴏsᴛ  Oɴ✓🔷🔹")
    else              
        if A21_FOUND and #A21_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A21_RESULTS)
            gg.getResults(#A21_RESULTS)
            gg.editAll("-9999999", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Fᴜʀy ʙᴏᴏsᴛ  Oғғ✓🔷🔹")
            return
        end
        gg.setRanges(gg.REGION_C_DATA)
        gg.searchNumber("4,926,515,780,927,168,184", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address + 0x78
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("999", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        A21_RESULTS = gg.getResults(10)
        A21_FOUND = true
        gg.editAll("-9999999", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Fᴜʀy ʙᴏᴏsᴛ  Oғғ✓🔷🔹")
    end
end

A22_FOUND = false
A22_RESULTS = {}
function a22()
    if state22 == on then
        if A22_FOUND and #A22_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A22_RESULTS)
            gg.getResults(#A22_RESULTS)
            gg.editAll("999", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷 Aɴɪᴍᴀʟ ʀᴀᴅᴀʀ Oɴ✓🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.searchNumber("1103626240", gg.TYPE_QWORD)
        local base = gg.getResults(100000)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0x280
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("20", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end        
        A22_RESULTS = gg.getResults(100000)
        A22_FOUND = true
        gg.editAll("999", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Aɴɪᴍᴀʟ ʀᴀᴅᴀʀ Oɴ✓🔷🔹")
    else  
        if A22_FOUND and #A22_RESULTS > 0 then
            gg.clearResults()
            gg.loadResults(A22_RESULTS)
            gg.getResults(#A22_RESULTS)
            gg.editAll("20", gg.TYPE_FLOAT)
            gg.clearResults()
            gg.toast("🔹🔷Aɴɪᴍᴀʟ ʀᴀᴅᴀʀ Oғғ ✓🔷🔹")
            return
        end
        gg.clearResults()
        gg.clearList()
        gg.searchNumber("1103626240", gg.TYPE_QWORD)
        local base = gg.getResults(100000)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address - 0x280
            v.flags = gg.TYPE_FLOAT
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("999", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            return
        end
        A22_RESULTS = gg.getResults(100000)
        A22_FOUND = true
        gg.editAll("20", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷Aɴɪᴍᴀʟ ʀᴀᴅᴀʀ Oғғ ✓🔷🔹")
    end
end

function a23()
if state19 == on then
state19 = off
Fly_RESULTS = {}
end 
if state1 == on then
state1 = off
gg.toast(" 🔹🔷 Save value deleted 🔷🔹")
end
end

function a24()
gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("4294952896X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(10000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -134
        i.flags = gg.TYPE_WORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("4X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  if gg.getResultsCount() < 1 then
    gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
  else
    r = gg.getResults(10)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
          t[i] = {
            address = i.address - 208,
            flags = 2,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address - 200,
            flags = 2,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address - 112,
            flags = 2,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address - 104,
            flags = 2,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address - 104,
            flags = 2,
            gg.addListItems(t)
          }
        end 
      end 
    end 
    t = gg.getListItems()
    gg.loadResults(t)
    revert = gg.getResults(100)
    gg.editAll("1;1;0;0" .. "+X6", gg.TYPE_WORD)
    gg.toast("🔹🔷Buy Now ✓🔷🔹")
    gg.clearList()
    gg.clearResults()
  end 
end

function a25()
gg.clearList()
gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("12,667,086,950,105,134", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
  result = gg.getResults(1)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
 v.address = v.address + 0xA8
 v.flags = gg.TYPE_FLOAT
end
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber("0.10000000149", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
 v.address = v.address + 0x8C
 v.flags = gg.TYPE_DWORD
end
  gg.loadResults(t)
  gg.clearList()
 gg.refineNumber("20", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0) 
   if gg.getResultCount() < 1 then
    gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
  gg.getResults(20000)
gg.editAll("9999999", gg.TYPE_DWORD)  
gg.toast("🔹🔷Lᴏɴɢ ɴᴀᴍᴇ  Oɴ✓🔷🔹")
gg.clearResults()
gg.clearList()
end
end


DATA = {} 
CPvalue = nil
HAVE_CP = nil
WANT_CP = nil
function a26()
  if HAVE_CP ~= nil then
    EDIT()
    return
  end
  local i = gg.prompt(
    {"How much CP you HAVE ❓"},
    {DATA["cp"] or ""},
    {"number"}
  )
  if not i then return end
  HAVE_CP = tonumber(i[1])
  DATA["cp"] = i[1]
--saveAll(DATA)
  if not HAVE_CP then
    gg.alert("Invalid number")
    return
  end
  if HAVE_CP <= 4294967296 then
    CP4B()
  else
    CP4P()
  end
end
function CP4B()
gg.clearList()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("4,503,810,114,328,195", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
  ressult = gg.getResults(1)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(ressult[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 0x5C
        i.flags = gg.TYPE_DWORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(HAVE_CP .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
    r = gg.getResults(100000)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
        end
      end
    end
    t = gg.getListItems()
    gg.loadResults(t)
    gg.refineNumber("10000~3000000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    gg.refineNumber(HAVE_CP .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local CP1 = gg.getResults(10000)
   local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 0x38
        i.flags = gg.TYPE_DWORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(HAVE_CP .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(50000)
  gg.addListItems(t)
  t = nil
    r = gg.getResults(10000)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
        end
      end
    end
    t = gg.getListItems()
    gg.loadResults(t)
    gg.refineNumber(HAVE_CP .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    gg.refineNumber("10000~3000000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local CP2 = gg.getResults(10000)
    gg.clearList()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("7,037,153,624,202,165", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
  result = gg.getResults(1)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 0x54
        i.flags = gg.TYPE_DWORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(HAVE_CP .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
    r = gg.getResults(100000)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
        end
      end
    end
    t = gg.getListItems()
    gg.loadResults(t)
    gg.refineNumber("10000~3000000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    gg.refineNumber(HAVE_CP .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local CP3 = gg.getResults(10000)
   local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 0x38
        i.flags = gg.TYPE_DWORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(HAVE_CP .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(50000)
  gg.addListItems(t)
  t = nil
    r = gg.getResults(10000)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
        end
      end
    end
    t = gg.getListItems()
    gg.loadResults(t)
    gg.refineNumber(HAVE_CP .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    gg.refineNumber("10000~3000000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local CP4 = gg.getResults(10000)
    gg.clearList()
    gg.clearResults()
    gg.addListItems(CP1)
    gg.addListItems(CP2)
    gg.addListItems(CP3)
    gg.addListItems(CP4)  
    local items = gg.getListItems()
    gg.loadResults(items)
  CPvalue = gg.getResults(10000)
  gg.clearList()
    gg.clearResults()
    EDIT()
end
function CP4P()
local refineValue = HAVE_CP
local DWORD_MAX = 4294967296
while refineValue >= DWORD_MAX do
    refineValue = refineValue - DWORD_MAX
end
local rangeMin = refineValue - 10
local rangeMax = refineValue + 10
if rangeMin < 0 then
    rangeMin = 0
end
gg.clearList()
    gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("4,503,810,114,328,195", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
  ressult = gg.getResults(1)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(ressult[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 0x5C
        i.flags = gg.TYPE_DWORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(rangeMin .. "~" .. rangeMax .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
    r = gg.getResults(100000)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
        end
      end
    end
    t = gg.getListItems()
    gg.loadResults(t)
    gg.refineNumber("10000~3000000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    gg.refineNumber(rangeMin .. "~" .. rangeMax .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local CP1 = gg.getResults(10000)
   local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 0x38
        i.flags = gg.TYPE_DWORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(rangeMin .. "~" .. rangeMax .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(50000)
  gg.addListItems(t)
  t = nil
    r = gg.getResults(10000)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
        end
      end
    end
    t = gg.getListItems()
    gg.loadResults(t)
    gg.refineNumber(rangeMin .. "~" .. rangeMax .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    gg.refineNumber("10000~3000000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local CP2 = gg.getResults(10000)
    gg.clearList()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("7,037,153,624,202,165", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
  result = gg.getResults(1)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 0x54
        i.flags = gg.TYPE_DWORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(rangeMin .. "~" .. rangeMax .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
    r = gg.getResults(100000)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
        end
      end
    end
    t = gg.getListItems()
    gg.loadResults(t)
    gg.refineNumber("10000~3000000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    gg.refineNumber(rangeMin .. "~" .. rangeMax .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local CP3 = gg.getResults(10000)
   local t = gg.getResults(500000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 0x38
        i.flags = gg.TYPE_DWORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(rangeMin .. "~" .. rangeMax .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(50000)
  gg.addListItems(t)
  t = nil
    r = gg.getResults(10000)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 16,
            flags = 4,
            gg.addListItems(t)
          }
        end
      end
    end
    t = gg.getListItems()
    gg.loadResults(t)
    gg.refineNumber(rangeMin .. "~" .. rangeMax .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    gg.refineNumber("10000~3000000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local CP4 = gg.getResults(10000)
    gg.clearList()
    gg.clearResults()
    gg.addListItems(CP1)
    gg.addListItems(CP2)
    gg.addListItems(CP3)
    gg.addListItems(CP4)  
    local items = gg.getListItems()
    gg.loadResults(items)
  CPvalue = gg.getResults(10000)
  gg.clearList()
    gg.clearResults()
    EDIT()
end
    function EDIT()
    local menu = gg.choice({
        "Edit 7M CP",
        "Edit 18M CP",
        "Edit 60M CP",
        "Custom CP"
    }, nil, "🔹🔷 Select how much CP you WANT 🔷🔹")
    if not menu then return end
    local FREEZ = false
    if menu == 1 then
        WANT_CP = 7000000
    elseif menu == 2 then
        WANT_CP = 18000000
    elseif menu == 3 then
        WANT_CP = 60000000
    elseif menu == 4 then
        local want = gg.prompt(
            {
                "How much CP you Want ❓",
                "Freeze CP"
            },
            {
                HAVE_CP,
                false
            },
            {
                "number",
                "checkbox"
            }
        )
        if not want then return end
        WANT_CP = tonumber(want[1])
        FREEZ = want[2]
        if not WANT_CP then
            gg.alert("❌ Invalid number!")
            return
        end
    end
    if WANT_CP <= 4294967296 then
        if FREEZ then
            EDITF1()
        else
            EDIT1()
        end
    else
        if FREEZ then
            EDITF2()
        else
            EDIT2()
        end
    end
end
    
        function EDIT1()
gg.clearResults()
gg.loadResults(CPvalue)
gg.getResults(100000)
gg.editAll(WANT_CP .. "+X12", gg.TYPE_DWORD)
local base = gg.getResults(100000)
local offsetResults = {}
for _, v in ipairs(base) do
    table.insert(offsetResults, {
        address = v.address - 0x4,
        flags = gg.TYPE_DWORD
    })
end
gg.loadResults(offsetResults)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("0X4", gg.TYPE_DWORD)
gg.toast("🔹🔷 CP Changed Successfully 🔷🔹")
gg.clearResults()
  end
  
function EDITF1()
gg.clearResults()
gg.loadResults(CPvalue)
gg.getResults(100000)
gg.editAll(WANT_CP .. "+X12", gg.TYPE_DWORD)
local CP5 = gg.getResults(10000)
    local base = gg.getResults(100000)
local offsetResults = {}
for _, v in ipairs(base) do
    table.insert(offsetResults, {
        address = v.address - 0x4,
        flags = gg.TYPE_DWORD
    })
end
gg.loadResults(offsetResults)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("0X4", gg.TYPE_DWORD)
gg.clearResults()
gg.loadResults(CP5)
local results = gg.getResults(100000)
if not results or #results < 2 then
    gg.alert("Not enough results")
    return
end

local temp = {}
local save = {}

for i = 1, #results, 2 do
    local v1 = results[i]
    local v2 = results[i + 1]
    if not v2 then break end

    for _, off in ipairs({0x0, -0x8, -0x4, 0x4, 0x8, 0xC, -0xC}) do
        table.insert(temp, {
            address = v1.address + off,
            flags   = gg.TYPE_FLOAT
        })
    end

    for _, off in ipairs({0x0, 0x4, 0x8, 0xC, 0x10}) do
        table.insert(temp, {
            address = v2.address + off,
            flags   = gg.TYPE_FLOAT
        })
    end
end

temp = gg.getValues(temp)
for _, v in ipairs(temp) do
    v.freeze = true
    table.insert(save, v)
end

gg.addListItems(save)
gg.toast("🔹🔷 CP Changed Successfully 🔷🔹")
end
  
  
  
  function EDIT2()
  local refineValue = WANT_CP
local DWORD_MAX = 4294967296
local wrapCount = 0  
while refineValue >= DWORD_MAX do
    refineValue = refineValue - DWORD_MAX
    wrapCount = wrapCount + 1
end
  gg.clearResults()
gg.loadResults(CPvalue)
gg.getResults(100000)
gg.editAll(refineValue .. "+X12", gg.TYPE_DWORD)
    local base = gg.getResults(100000)
local offsetResults = {}
for _, v in ipairs(base) do
    table.insert(offsetResults, {
        address = v.address - 0x4,
        flags = gg.TYPE_DWORD
    })
end
gg.loadResults(offsetResults)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll(wrapCount .. "+X4", gg.TYPE_DWORD)
gg.clearResults()
  gg.toast("🔹🔷 CP Changed Successfully 🔷🔹")
  end 
  
  function EDITF2()
  local refineValue = WANT_CP
local DWORD_MAX = 4294967296
local wrapCount = 0  
while refineValue >= DWORD_MAX do
    refineValue = refineValue - DWORD_MAX
    wrapCount = wrapCount + 1
end
  gg.clearResults()
gg.loadResults(CPvalue)
gg.getResults(100000)
gg.editAll(refineValue .. "+X12", gg.TYPE_DWORD)
  local CP6 = gg.getResults(10000)
    local base = gg.getResults(100000)
local offsetResults = {}
for _, v in ipairs(base) do
    table.insert(offsetResults, {
        address = v.address - 0x4,
        flags = gg.TYPE_DWORD
    })
end
gg.loadResults(offsetResults)
revert = gg.getResults(9999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll(wrapCount .. "+X4", gg.TYPE_DWORD)
gg.clearResults()
gg.loadResults(CP5)
local results = gg.getResults(100000)
if not results or #results < 2 then
    gg.alert("Not enough results")
    return
end
local temp = {}
local save = {}
for i = 1, #results, 2 do
    local v1 = results[i]
    local v2 = results[i + 1]
    if not v2 then break end

    for _, off in ipairs({0x0, -0x8, -0x4, 0x4, 0x8, 0xC, -0xC}) do
        table.insert(temp, {
            address = v1.address + off,
            flags   = gg.TYPE_FLOAT
        })
    end
    for _, off in ipairs({0x0, 0x4, 0x8, 0xC, 0x10}) do
        table.insert(temp, {
            address = v2.address + off,
            flags   = gg.TYPE_FLOAT
        })
    end
end
temp = gg.getValues(temp)
for _, v in ipairs(temp) do
    v.freeze = true
    table.insert(save, v)
end
gg.addListItems(save)
gg.toast("🔹🔷 CP Changed Successfully 🔷🔹")
  end
  
  
  
  
  
function a27()
    gg.clearList()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    local values = gg.prompt({ 
        "Hᴏᴡ ᴍᴀɴʏ Cᴏɪɴ Hᴀᴄᴋ💰, Gᴇᴍs Hᴀᴄᴋ💎, Mᴏᴏɴ🌙, ᴅᴏ ʏᴏᴜ ʜᴀᴠᴇ?",
        "Hᴏᴡ ᴍᴀɴʏ Cᴏɪɴ Hᴀᴄᴋ💰, Gᴇᴍs Hᴀᴄᴋ💎, Mᴏᴏɴ🌙, ᴅᴏ ʏᴏᴜ ᴡᴀɴᴛ?"
    }, {}, { 
        "number",
        "number"
    })
    if values == nil then
        return
    end 
    gg.searchNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local cnt = gg.getResultCount()
    if cnt == 0 then
        gg.alert("⚠️ Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ ᴏʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
        return
    end
    while true do
        cnt = gg.getResultCount()
        if cnt < 15 and cnt > 0 then
            local revert = gg.getResults(12000000)    
            gg.editAll(values[2] .. "+X12", gg.TYPE_DWORD)
            gg.toast("🔹🔷 Cᴏɪɴ Gems Moon ʜᴀᴄᴋ Dᴏɴᴇ ✓🔷🔹")
            gg.clearResults()
            break
        elseif cnt == 0 then
            gg.alert("⚠️ Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ ᴀғᴛᴇʀ ʀᴇғɪɴᴇ... Tʀʏ ᴀɢᴀɪɴ.")
            gg.clearResults()
            break           
        else
            gg.toast("⚠️ " .. cnt .. " results left! Change value in game ᴀɴᴅ Tʜᴇɴ ᴛᴀᴘ 👉 GG Iᴄᴏɴ")
            while not gg.isVisible(true) do
                gg.sleep(150) 
            end
            gg.setVisible(false)
            local valuess = gg.prompt({"Refine ʜᴏᴡ ᴍᴜᴄʜ ʏᴏᴜ have now??"}, {}, {"number"})
            if not valuess then 
                gg.toast("❌ Script Cancelled")
                break 
            end
            gg.refineNumber(valuess[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
            gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        end
    end
end


function a28()
gg.clearList()
gg.clearResults()
  local values = gg.prompt({
    "Hᴏᴡ ᴍᴀɴʏ Cᴏɪɴ ʏᴏᴜ ʜᴀᴠᴇ",
    "How ᴍᴀɴʏ Gᴇᴍs ʏᴏᴜ ʜᴀᴠᴇ",
    "How ᴍᴀɴʏ Mᴏᴏɴ ʏᴏᴜ ʜᴀᴠᴇ",
  }, {}, {
    "number",
    "number",
    "number",
  })
  if values == nil then
    return
  end 
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 96
        i.flags = gg.TYPE_DWORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[2] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if gg.getResultsCount() < 1 then
    gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
  gg.clearList()
  local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("-9X12", gg.TYPE_DWORD)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -96
        i.flags = gg.TYPE_DWORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
 gg.editAll("-9X12", gg.TYPE_DWORD)
 gg.clearList()
gg.clearResults()
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -96
        i.flags = gg.TYPE_DWORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[3] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("-9X12", gg.TYPE_DWORD)
  gg.addListItems(t)
  t = nil
gg.toast("🔹🔷Cᴏɪɴ,Gᴇᴍs Hᴀᴄᴋᴇᴅ✓🔷🔹")
gg.clearResults()
gg.clearList()
end
end

function a29()
gg.clearResults()
gg.clearList()
  local values = gg.prompt({
    "Hᴏᴡ ᴍᴀɴʏ xᴘ ᴘᴏɪɴᴛ ᴅᴏ ʏᴏᴜ ʜᴀᴠᴇ",
    "Wʜᴀᴛ ɪs ʏᴏᴜʀ ᴄᴜʀʀᴇᴛ ʟᴠʟ",
    "Hᴏᴡ Mᴀɴʏ Xᴘ ᴘᴏɪɴᴛ ʏᴏᴜ ᴡᴀɴᴛ?"
  }, {}, {"number", "number"})
  if values == nil then
    return
  end
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(values[1] .. "~" .. values[1] + 10 .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 16
        if copy then
          i.name = i.name .. " #2"
        end
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[1] .. "~" .. values[1] + 10 .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -54
        i.flags = gg.TYPE_WORD
        if copy then
          i.name = i.name .. " #2"
        end
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[2] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  if 1 > gg.getResultsCount() then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
  else
    r = gg.getResults(10)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
          t[i] = {
            address = i.address,
            flags = 2,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 8,
            flags = 2,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 38,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 54,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 54,
            flags = 4,
            gg.addListItems(t)
          }
        end
      end
    end
    t = gg.getListItems()
    for i, i in ipairs(t) do
      i.address = i.address - 4
    end
    gg.loadResults(t)
    gg.getResults(100000)
    gg.editAll(values[3] .. "+X4", gg.TYPE_DWORD)
    gg.getResults(100000)
        gg.toast("🔹🔷Xᴘ Vᴀʟᴜᴇ Cʜᴀɴɢᴇᴅ ✓🔷🔹")
        gg.clearResults()
        gg.clearList()
  end
end


function a30()
gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("12884901891", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("12884901891", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -124
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("4294967296", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 272
        i.flags = gg.TYPE_WORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("16670~18800X2", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = true
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 8
        i.flags = gg.TYPE_WORD
        i.name = ""
        if copy then
          i.name = i.name .. " "
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("16670~18800X2", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if gg.getResultsCount() < 1 then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
    revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
    gg.editAll("16630" .. "+X2", gg.TYPE_WORD)
    end
    gg.clearList()
    gg.clearResults()
    gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("12884901891", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("12884901891", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -124
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("4,294,967,410~4,294,967,420", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 272
        i.flags = gg.TYPE_WORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("16670~18800X2", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = true
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 8
        i.flags = gg.TYPE_WORD
        i.name = ""
        if copy then
          i.name = i.name .. " "
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("16670~18800X2", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if gg.getResultsCount() < 1 then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
    revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
        gg.editAll("16630" .. "+X2", gg.TYPE_WORD)
    local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = true
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 32
        i.flags = gg.TYPE_WORD
        i.name = ""
        if copy then
          i.name = i.name .. " "
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
    if gg.getResultsCount() < 1 then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
    revert = gg.getResults(1000, nil, nil, nil, nil, nil, nil, nil, nil)
          gg.editAll("16630" .. "+X2", gg.TYPE_WORD)
          gg.toast("🔹🔷Cᴏᴏʟᴅᴡᴏɴ 9 sᴇᴄ Oɴ✓🔷🔹")
          gg.clearResults()
          gg.clearList()
    end
  end 
end

function a31()
gg.clearList()
    gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("1125990134717378", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
  result = gg.getResults(100000)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 30
        i.flags = gg.TYPE_WORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber("200~65000", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("0~100X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if 1 > gg.getResultsCount() then
    gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
  else
  gg.clearList()
  local values = gg.prompt({
      "Wʜᴀᴛ ʟᴠʟ ᴏғ Sᴋɪʟʟ ʏᴏᴜ ᴡᴀɴᴛ "
    }, {}, {"number"})
    if values == nil then
      return
    end
    r = gg.getResults(1000)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
        t[i] = {
        	address = i.address,
            flags = 2,
            gg.addListItems(t)
          }
    t[i] = {
        address = i.address + 8,
            flags = 2,
            gg.addListItems(t)
          }
          t[i] = {
        address = i.address + 8,
            flags = 2,
            gg.addListItems(t)
          }
        end
      end
    end
    t = gg.getListItems()
    gg.loadResults(t)
    revert = gg.getResults(1000)
    gg.editAll(values[1] .. "+X6", gg.TYPE_WORD)
    gg.toast("🔹🔷 Sᴋɪʟʟ ʟᴠʟ Cʜᴀɴɢᴇᴅ✓🔷🔹")
  gg.clearList()
    gg.clearResults()
    end
end

function a32()
gg.clearList()
gg.clearResults()
  local values = gg.prompt({
    "Hᴏᴡ ᴍᴀɴʏ xᴘ ᴘᴏɪɴᴛ ᴅᴏ ʏᴏᴜ ʜᴀᴠᴇ",
    "Wʜᴀᴛ ɪs ʏᴏᴜʀ ᴄᴜʀʀᴇᴛ ʟᴠʟ",
    "Wʜᴀᴛ ʟᴠʟ ʏᴏᴜ ᴡᴀɴᴛ "
  }, {}, {
    "number",
    "number",
    "number"
  })
  if values == nil then
    return
  end 
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -38
        i.flags = gg.TYPE_WORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[2] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = true
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 8
        i.name = ""
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[2] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  if 1 > gg.getResultCount() then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
    revert = gg.getResults(1000, nil, nil, nil, nil, nil, nil, nil, nil)
    gg.editAll(values[3] .. "+X6", gg.TYPE_WORD)
   gg.toast("🔹🔷Lᴇᴠᴇʟ Cʜᴀɴɢᴇᴅ ✓🔷🔹")
  end 
end

function a33()
gg.setRanges(gg.REGION_ANONYMOUS)
  gg.clearList()
  gg.clearResults()
  local values = gg.prompt({
    "Yᴏᴜʀ ʜᴇᴀʟᴛʜ ʟᴠʟ",
    "Yᴏᴜʀ ᴅᴇғᴇɴᴄᴇ ʟᴠʟ",
    "Yᴏᴜʀ ᴀᴛᴛᴀᴄᴋ ʟᴠʟ",
    "Yᴏᴜʀ sᴘᴇᴇᴅ ʟᴠʟ",
   }, {}, {
    "number",
    "number",
    "number",
    "number",
  })
  if values == nil then
    return
  end 
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(values[3] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(300000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 8
        if copy then
          i.name = i.name .. "2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[3] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(300000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 32
        if copy then
          i.name = i.name .. "2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[2] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(300000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 32
        if copy then
          i.name = i.name .. "2"
        end 
      end 
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(300000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 32
        if copy then
          i.name = i.name .. "2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[4] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(300000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -104
        if copy then
          i.name = i.name .. "2"
        end 
      end 
    end
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[3] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  if 1 > gg.getResultsCount() then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
  else
    local cara = gg.prompt({
      "Wʜᴀᴛ ʜᴇᴀʟᴛʜ ʟᴠʟ ʏᴏᴜ ᴡᴀɴᴛ",
      "Wʜᴀᴛ ᴅᴇғᴇɴᴄᴇ ʟᴠʟ ʏᴏᴜ ᴡᴀɴᴛ",
      "Wʜᴀᴛ ᴀᴛᴛᴀᴄᴋ ʟᴠʟ ʏᴏᴜ ᴡᴀɴᴛ",
      "Wʜᴀᴛ sᴘᴇᴇᴅ ʟᴠʟ ʏᴏᴜ ᴡᴀɴᴛ",
    }, {}, {
      "number",
      "number",
      "number",
      "number",
    })
    if cara == nil then
      return
    end 
    r = gg.getResults(10)
    local x = {}
    do
      do
        for i, i in ipairs(r) do
          x[i] = {
            address = i.address,
            flags = 2,
            value = cara[3] .. "+X6",
            gg.setValues(x)
          }
          x[i] = {
            address = i.address + 8,
            flags = 2,
            value = cara[3] .. "+X6",
            gg.setValues(x)
          }
          x[i] = {
            address = i.address + 32,
            flags = 2,
            value = cara[2] .. "+X6",
            gg.setValues(x)
          }
          x[i] = {
            address = i.address + 40,
            flags = 2,
            value = cara[2] .. "+X6",
            gg.setValues(x)
          }
          x[i] = {
            address = i.address + 64,
            flags = 2,
            value = cara[1] .. "+X6",
            gg.setValues(x)
          }
          x[i] = {
            address = i.address + 72,
            flags = 2,
            value = cara[1] .. "+X6",
            gg.setValues(x)
          }
          x[i] = {
            address = i.address + 96,
            flags = 2,
            value = cara[4] .. "+X6",
            gg.setValues(x)
          }
          x[i] = {
            address = i.address + 104,
            flags = 2,
            value = cara[4] .. "+X6",
            gg.setValues(x)
          }
          x[i] = {
            address = i.address + 104,
            flags = 2,
            value = cara[4] .. "+X6",
            gg.setValues(x)
          }
        end 
      end 
    end 
    gg.toast("🔹🔷Aʀᴛᴛɪʙᴜᴛᴇs Cʜᴀɴɢᴇᴅ ✓🔷🔹")
    gg.clearResults()
    gg.clearList()
  end 
end

function a34()
gg.clearList()
gg.clearResults()
local values = gg.prompt({
   "What Aɴɪᴍᴀʟ Lᴠʟ you see❓❓",
   "What Aɴɪᴍᴀʟ Lᴠʟ you want❓❓",
  }, {}, {
    "number",
    "number",
  })
  if values == nil then
    return
  end 
    gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("844,536,632,838,141", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
  result = gg.getResults(1)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(500)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 0x3E
        i.flags = gg.TYPE_WORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if 1 > gg.getResultsCount() then
    gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
  else
  local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
 v.address = v.address + 0x40
 v.flags = gg.TYPE_WORD
end
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
 v.address = v.address + -0x40
 v.flags = gg.TYPE_WORD
end
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
 v.address = v.address + 0x8
 if copy then v.name = v.name..' #2' end
end
gg.addListItems(t)
t = nil
copy = nil
local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500;200~65500::9", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.getResults(100000)
    gg.editAll(values[2].. "+X6", gg.TYPE_WORD)
   gg.toast("🔹🔷 Aɴɪᴍᴀʟ Lᴠʟ Cʜᴀɴɢᴇ✓🔷🔹")
   gg.clearList()
   gg.clearResults()
  end
end

function a35()
gg.clearList()
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("50;5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("50", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(50000000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 16
        i.flags = gg.TYPE_FLOAT
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber("5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(50000000)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -16
        i.flags = gg.TYPE_FLOAT
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber("50", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(980088, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
	v.address = v.address + -0x20
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(t)
t = nil
copy = nil
gg.clearResults()
t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber("10~14", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(980088, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
	v.address = v.address + 0x20
	if copy then v.name = v.name..' #2' end
end
gg.addListItems(t)
t = nil
copy = nil
gg.clearResults()
t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
gg.refineNumber("50", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
if 1 > gg.getResultsCount() then
    gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
  else
  gg.getResults(20000)
gg.editAll("0", gg.TYPE_FLOAT)
gg.toast("🔹🔷 Poʀᴛ ᴀɴᴅ Tʀᴀᴘs Aɴyᴡʜᴇʀᴇ ✓🔷🔹")  
end
end

function a36()
gg.clearResults()
gg.clearList()
  UN = gg.multiChoice({
    "Lᴇᴠᴇʟ  Uɴʙᴀɴ",
    "Aʀᴛᴛɪʙᴜᴛᴇs Uɴʙᴀɴ",
    "Coin Unban",
"👣🇪 🇽 🇮 🇹 👣"
}, nil, "ﾟ??🇭 🇦 🇨 🇰 ༺♡༻  🇲 🇪 🇳 🇺 💖 ﾟ")
 if UN == nil then 
 else
if UN[1] == true then
    UN1()
end 

if UN[2] == true then
    UN2()
end 

if UN[3] == true then
UN3()
end

if UN[4] == true then
HOME()
    end
end
  PUBGMH = -1
end

function UN1()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("2533399378009144", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
local result = gg.getResults(1)
if #result == 0 then 
return 
end
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(5000)
gg.clearList()
local t2 = {}
for k, v in ipairs(t) do
table.insert(t2, {address = v.address + 0xBC, flags = gg.TYPE_DWORD})
table.insert(t2, {address = v.address + 0xCC, flags = gg.TYPE_DWORD})
end
gg.addListItems(t2)
t = gg.getListItems()
gg.loadResults(t)
gg.clearList()
gg.refineNumber("700X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
if gg.getResultsCount() ~= 0 then
gg.getResults(10)
gg.editAll("0X12", gg.TYPE_DWORD)
gg.clearResults()
end
gg.toast("🔹🔷Lᴇᴠᴇʟ  Uɴʙᴀɴ 🔷🔹")
gg.clearResults()
gg.clearList()
end

function UN2()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("1970436539685907", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
local result = gg.getResults(1)
if #result == 0 then return end
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(5000)
gg.clearList()
local t2 = {}
for k, v in ipairs(t) do
table.insert(t2, {address = v.address + 0x124, flags = gg.TYPE_DWORD})
table.insert(t2, {address = v.address + 0x134, flags = gg.TYPE_DWORD})
end
gg.addListItems(t2)
t = gg.getListItems()
gg.loadResults(t)
gg.clearList()
gg.refineNumber("5000000X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
if gg.getResultsCount() ~= 0 then
gg.getResults(10)
gg.editAll("-9X12", gg.TYPE_DWORD)
gg.clearResults()
end
 gg.toast(" 🔹🔷 Aʀᴛᴛɪʙᴜᴛᴇs Uɴʙᴀɴ ✓ 🔷🔹")
 gg.clearResults()
 gg.clearList()
 end
 
 
 function UN3()
 gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("563031591361003", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
local result = gg.getResults(1)
if #result == 0 then 
return 
end
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(5000)
gg.clearList()
local t2 = {}
for k, v in ipairs(t) do
table.insert(t2, {address = v.address + 0x24, flags = gg.TYPE_DWORD})
table.insert(t2, {address = v.address + 0x34, flags = gg.TYPE_DWORD})
end
gg.addListItems(t2)
t = gg.getListItems()
gg.loadResults(t)
gg.clearList()
gg.refineNumber("500000X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
if gg.getResultsCount() ~= 0 then
gg.getResults(100)
gg.editAll("-9X12", gg.TYPE_DWORD)
end
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("563031591361003", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
local result = gg.getResults(1)
if #result == 0 then return end
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(5000)
gg.clearList()
local t2 = {}
for k, v in ipairs(t) do
table.insert(t2, {address = v.address + 0x24, flags = gg.TYPE_DWORD})
table.insert(t2, {address = v.address + 0x34, flags = gg.TYPE_DWORD})
end
gg.addListItems(t2)
t = gg.getListItems()
gg.loadResults(t)
gg.clearList()
gg.refineNumber("4000X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
if gg.getResultsCount() ~= 0 then
gg.getResults(100)
gg.editAll("1X12", gg.TYPE_DWORD)
gg.clearResults()
end
gg.toast("🔹🔷 Coin Unban ✓🔷🔹")
gg.clearResults()
end

function a37()
gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("12884901891", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("12884901891", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -124
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("4,294,967,410~4,294,967,420", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 272
        i.flags = gg.TYPE_WORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("16670~18800X2", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = true
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 8
        i.flags = gg.TYPE_WORD
        i.name = ""
        if copy then
          i.name = i.name .. " "
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("15000~18800X2", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if gg.getResultsCount() < 1 then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
    revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
    gg.editAll("0" .. "+X2", gg.TYPE_WORD)
    local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = true
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 32
        i.flags = gg.TYPE_WORD
        i.name = ""
        if copy then
          i.name = i.name .. " "
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
    if gg.getResultsCount() < 1 then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
    revert = gg.getResults(1000, nil, nil, nil, nil, nil, nil, nil, nil)
      gg.editAll("0" .. "+X2", gg.TYPE_WORD)
     gg.toast("🔹🔷Tʀᴀᴘs Cᴏᴏʟᴅᴏᴡɴ Oɴ✓🔷🔹")
    gg.clearResults()
   gg.clearList()
  end
 end 
end

function a38()
gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("12884901891", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("12884901891", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -124
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("4294967296", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 272
        i.flags = gg.TYPE_WORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("16670~18800X2", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = true
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 8
        i.flags = gg.TYPE_WORD
        i.name = ""
        if copy then
          i.name = i.name .. " "
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("16670~18800X2", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if gg.getResultsCount() < 1 then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
    revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
    gg.editAll("0" .. "+X2", gg.TYPE_WORD)
    end
    gg.clearList()
    gg.clearResults()
    gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("12884901891", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("12884901891", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -124
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("4,294,967,410~4,294,967,420", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 272
        i.flags = gg.TYPE_WORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("16670~18800X2", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = true
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 8
        i.flags = gg.TYPE_WORD
        i.name = ""
        if copy then
          i.name = i.name .. " "
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber("16670~18800X2", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if gg.getResultsCount() < 1 then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
    revert = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
        gg.editAll("0" .. "+X2", gg.TYPE_WORD)
    local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = true
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 32
        i.flags = gg.TYPE_WORD
        i.name = ""
        if copy then
          i.name = i.name .. " "
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
    if gg.getResultsCount() < 1 then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
    revert = gg.getResults(1000, nil, nil, nil, nil, nil, nil, nil, nil)
          gg.editAll("0" .. "+X2", gg.TYPE_WORD)
          gg.toast("🔹🔷Cᴏᴏʟᴅᴡᴏɴ sᴇᴄ Oɴ✓🔷🔹")
          gg.clearResults()
          gg.clearList()
    end
  end 
end

function a39()
gg.clearList()
  gg.clearResults()
  local values = gg.prompt({
    "Hᴏᴡ ᴍᴀɴʏ Cᴏɪɴ ʏᴏᴜ ʜᴀᴠᴇ 🪙",
    "How ᴍᴀɴʏ Gᴇᴍs ʏᴏᴜ ʜᴀᴠᴇ 💎",
    "How ᴍᴀɴʏ Mᴏᴏɴ ʏᴏᴜ ʜᴀᴠᴇ 🌙",
  }, {}, {
    "number",
    "number",
    "number",
  })
  if values == nil then
    return
  end 
  local items_to_edit = {}
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 96
        i.flags = gg.TYPE_DWORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[2] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if gg.getResultsCount() < 1 then
    gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
  else
    gg.clearList()
    local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
    for k, v in ipairs(t) do
      table.insert(items_to_edit, {address = v.address - 4, flags = gg.TYPE_DWORD, value = "999999X4", name = "Gems Up Value"})
    end
    gg.addListItems(t)
    t = nil
    local copy = false
    local t = gg.getListItems()
    if not copy then
      gg.removeListItems(t)
    end 
    do
      do
        for i, i in ipairs(t) do
          i.address = i.address + -96
          i.flags = gg.TYPE_DWORD
          if copy then
            i.name = i.name .. " #2"
          end 
        end 
      end 
    end 
    gg.addListItems(t)
    copy, t = nil, nil
    gg.clearResults()
    t = gg.getListItems()
    gg.loadResults(t)
    gg.clearList()
    revert = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
    for k, v in ipairs(revert) do
      table.insert(items_to_edit, {address = v.address - 4, flags = gg.TYPE_DWORD, value = "999999X4", name = "Coins Up Value"})
    end
    gg.clearList()
    gg.clearResults()
    gg.addListItems(t)
    t = nil
    local copy = false
    local t = gg.getListItems()
    if not copy then
      gg.removeListItems(t)
    end 
    do
      do
        for i, i in ipairs(t) do
          i.address = i.address + -96
          i.flags = gg.TYPE_DWORD
          if copy then
            i.name = i.name .. " #2"
          end 
        end 
      end 
    end 
    gg.addListItems(t)
    copy, t = nil, nil
    gg.clearResults()
    t = gg.getListItems()
    gg.loadResults(t)
    gg.refineNumber(values[3] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
    local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
    for k, v in ipairs(t) do
      table.insert(items_to_edit, {address = v.address - 4, flags = gg.TYPE_DWORD, value = "999999X4", name = "Moon Up Value"})
    end
    gg.addListItems(t)
    t = nil
    gg.setValues(items_to_edit)
    gg.addListItems(items_to_edit)
    gg.clearResults()
    gg.clearList()
    gg.toast("🔹🔷Cᴏɪɴ,Gᴇᴍs & Mᴏᴏɴ Tʀɪʟʟɪᴏɴ Hᴀᴄᴋᴇᴅ✓🔷🔹")
  end
end

function a40()
  gg.clearList()
  gg.clearResults()
  gg.searchNumber("214,261,49X12", gg.TYPE_DWORD)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  gg.getResults(9999)
  gg.editAll("-9X12", gg.TYPE_DWORD)  
  gg.clearResults()
  gg.searchNumber("17262X12", gg.TYPE_DWORD)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  gg.getResults(9999)
  gg.editAll("-9X12", gg.TYPE_DWORD)  
  gg.clearResults()
  gg.searchNumber("1125X12", gg.TYPE_DWORD)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  gg.getResults(9999)
  gg.editAll("-9X12", gg.TYPE_DWORD) 
  gg.clearList()
  gg.clearResults()
  local values = gg.prompt({
    "Hᴏᴡ ᴍᴀɴʏ Cᴏɪɴ ʏᴏᴜ Wɪɴ🪙",
    "How ᴍᴀɴʏ Gᴇᴍs ʏᴏᴜ Wɪɴ💎",
    "How ᴍᴀɴʏ Mᴏᴏɴ ʏᴏᴜ Wɪɴ🌙",
  }, {}, {
    "number",
    "number",
    "number",
  })
  if values == nil then
    return
  end 
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if gg.getResultsCount() < 1 then
    gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
    return
  end  
  local base = gg.getResults(100000) 
  gg.clearList()
  gg.addListItems(base)
  local t = gg.getListItems()
  gg.removeListItems(t)
  do
    for k, v in ipairs(t) do
      v.address = v.address - 112
      v.flags = gg.TYPE_DWORD
    end 
  end 
  gg.addListItems(t)
  gg.clearResults()
  gg.loadResults(t)
  gg.refineNumber(values[2] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  if gg.getResultsCount() > 0 then
    gg.getResults(100)
    gg.editAll("-9X12", gg.TYPE_DWORD)
  end
  gg.clearList()
  gg.addListItems(base)
  local t = gg.getListItems()
  gg.removeListItems(t)
  do
    for k, v in ipairs(t) do
      v.address = v.address - 168
      v.flags = gg.TYPE_DWORD
    end 
  end 
  gg.addListItems(t)
  gg.clearResults()
  gg.loadResults(t)
  gg.refineNumber(values[3] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  local moon = {}
  if gg.getResultsCount() > 0 then
    moon = gg.getResults(100)
    gg.editAll("-9X12", gg.TYPE_DWORD)
  end
  gg.clearList()
  gg.addListItems(moon)
  local t = gg.getListItems()
  gg.removeListItems(t)
  do
    for k, v in ipairs(t) do
      v.address = v.address + 168
      v.flags = gg.TYPE_DWORD
    end 
  end 
  gg.addListItems(t)
  gg.clearResults()
  gg.loadResults(t)
  gg.refineNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  if gg.getResultsCount() > 0 then
    gg.getResults(100)
    gg.editAll("-9X12", gg.TYPE_DWORD)
  end
  gg.clearList()
  gg.clearResults()
  gg.toast("🔹🔷Wɪɴ Pʀɪzᴇ Vᴀʟᴜᴇ Cʜᴀɴɢᴇᴅ ✓🔷🔹")
end

function a41()
  gg.clearList()
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("214,261,49X12", gg.TYPE_DWORD)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  gg.getResults(9999)
  gg.editAll("-9X12", gg.TYPE_DWORD)  
  gg.clearResults()
  gg.searchNumber("17262X12", gg.TYPE_DWORD)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  gg.getResults(9999)
  gg.editAll("-9X12", gg.TYPE_DWORD)  
  gg.clearResults()
  gg.searchNumber("1125X12", gg.TYPE_DWORD)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  gg.getResults(9999)
  gg.editAll("-9X12", gg.TYPE_DWORD) 
  gg.clearList()
gg.clearResults()
  local values = gg.prompt({
    "Hᴏᴡ ᴍᴀɴʏ ᴄᴏɪɴ ʏᴏᴜ ᴡɪɴ ?\n🪙💰🪙💰🪙💰🪙💰🪙💰🪙💰🪙",
    "How ᴍᴀɴʏ ɢᴇᴍs ʏᴏᴜ ᴡɪɴ ?\n💎💎💎💎💎💎💎💎💎💎💎💎💎",
    "How ᴍᴀɴʏ ᴍᴏᴏɴ ʏᴏᴜ ᴡɪɴ ?\n🌙🌙🌙🌙🌙🌙🌙🌙🌙🌙🌙🌙🌙",
  }, {}, {
    "number",
    "number",
    "number",
  })
  if values == nil then
    return
  end   
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -112
        i.flags = gg.TYPE_DWORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[2] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -56
        i.flags = gg.TYPE_DWORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[3] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 56
        i.flags = gg.TYPE_DWORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[2] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  gg.addListItems(t)
  t = nil 
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 112
        i.flags = gg.TYPE_DWORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
 gg.refineNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
 if gg.getResultsCount() < 1 then
 gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
  else
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 56
        i.flags = gg.TYPE_DWORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
 gg.refineNumber("0X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end 
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 56
        i.flags = gg.TYPE_DWORD
        if copy then
          i.name = i.name .. " #2"
        end 
      end 
    end 
  end 
  gg.addListItems(t)
  copy, t = nil, nil
  gg.clearResults()
  t = gg.getListItems()
  gg.loadResults(t)
 gg.refineNumber("0X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
 gg.refineNumber("10000000~2300000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
 local cara = gg.prompt({
      "Hᴏᴡ ᴍᴀɴʏ ᴄᴏɪɴ ʏᴏᴜ ɴᴇᴇᴇᴅ\n🪙🪙🪙🪙🪙🪙🪙🪙",
      "Hᴏᴡ ᴍᴀɴʏ ɢᴇᴍs ʏᴏᴜ ɴᴇᴇᴅ\n💎💎💎💎💎💎💎💎",
      "Hᴏᴡ ᴍᴀɴʏ ᴍᴏᴏɴ ʏᴏᴜ ɴᴇᴇᴅ\n🌙🌙🌙🌙🌙🌙🌙🌙",
      "Hᴏᴡ ᴍᴀɴʏ Xᴘ ʏᴏᴜ ɴᴇᴇᴅ\n⭐⭐⭐⭐⭐⭐⭐⭐",
      "Hᴏᴡ ᴍᴀɴʏ ᴄᴏᴍᴘ ᴛɪᴄᴋᴇᴛ ʏᴏᴜ ɴᴇᴇᴅ\n🎟️🎟️🎟️🎟️🎟️🎟️🎟️🎟️",     
      "Hᴏᴡ ᴍᴀɴʏ ʀᴇᴅ ᴛᴏᴋᴇɴ ʏᴏᴜ ɴᴇᴇᴇᴅ\n♦️♦️♦️♦️♦️♦️♦️♦️",    
    }, {
         -9, -9, -9, 0, 0, 0
        }, {
      "number",
      "number",
      "number",
      "number",
      "number",
      "number",
    })
    if cara == nil then
      return
    end 
    r = gg.getResults(10)
    local x = {}
    do
      do
        for i, i in ipairs(r) do
          x[i] = {
            address = i.address,
            flags = 4,
            value = cara[6] .. "+X12",
            gg.setValues(x)
          }
          x[i] = {
            address = i.address,
            flags = 4,
            value = cara[6] .. "+X12",
            gg.setValues(x)
          }
          x[i] = {
            address = i.address - 56,
            flags = 4,
            value = cara[5] .. "+X12",
            gg.setValues(x)
          }          
          x[i] = {
            address = i.address - 112,
            flags = 4,
            value = cara[1] .. "+X12",
            gg.setValues(x)
          }          
          x[i] = {
            address = i.address - 168,
            flags = 4,
            value = cara[4] .. "+X12",
            gg.setValues(x)
          }       
            x[i] = {
            address = i.address - 224,
            flags = 4,
            value = cara[2] .. "+X12",
            gg.setValues(x)
          }        
          x[i] = {
            address = i.address - 280,
            flags = 4,
            value = cara[3] .. "+X12",
            gg.setValues(x)
          }
          x[i] = {
            address = i.address - 280,
            flags = 4,
            value = cara[3] .. "+X12",
            gg.setValues(x)
          }
        end 
      end 
    end   
  gg.toast("🔹🔷Wɪɴ Pʀɪᴄᴇ Vᴀʟᴜᴇ Cʜᴀɴɢᴇᴅ 2 ✓🔷🔹")
  gg.clearList()
  gg.clearResults()
  end
  end

function a42()
gg.clearResults()
gg.clearList()
  AI = gg.multiChoice({
    "2000 Sᴋɪɴ",
    "900 Sᴋɪɴ",
    "600 Sᴋɪɴ",
       "👣🇪 🇽 🇮 🇹 👣"
}, nil, "ﾟ💖🇭 🇦 🇨 🇰 ༺♡༻  🇲 🇪 🇳 🇺 💖 ﾟ")
 if AI == nil then 
 else
if AI[1] == true then
    AI1()
end 

if AI[2] == true then
    AI2()
end 

if AI[3] == true then
    AI3()
end 

if AI[4] == true then
HOME()
    end
end
  PUBGMH = -1
end

function AI1()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("563031591361003", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
local result = gg.getResults(1)
if #result == 0 then 
return 
end
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(50000)
gg.clearList()
local t2 = {}
for k, v in ipairs(t) do
table.insert(t2, {address = v.address + 0x24, flags = gg.TYPE_DWORD})
table.insert(t2, {address = v.address + 0x34, flags = gg.TYPE_DWORD})
end
gg.addListItems(t2)
t = gg.getListItems()
gg.loadResults(t)
gg.clearList()
gg.refineNumber("2000X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll("1X12", gg.TYPE_DWORD)
gg.clearResults()
gg.toast("🔹🔷1 Mᴏᴏɴ Sᴋɪɴ ✓ 🔷🔹")
end

function AI2()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("563031591361003", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
local result = gg.getResults(1)
if #result == 0 then 
return 
end
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(50000)
gg.clearList()
local t2 = {}
for k, v in ipairs(t) do
table.insert(t2, {address = v.address + 0x24, flags = gg.TYPE_DWORD})
table.insert(t2, {address = v.address + 0x34, flags = gg.TYPE_DWORD})
end
gg.addListItems(t2)
t = gg.getListItems()
gg.loadResults(t)
gg.clearList()
gg.refineNumber("900X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll("1X12", gg.TYPE_DWORD)
gg.clearResults()
gg.toast("🔹🔷1 Mᴏᴏɴ Sᴋɪɴ ✓ 🔷🔹")
end

function AI3()
gg.clearResults()
gg.clearList()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("563031591361003", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
local result = gg.getResults(1)
if #result == 0 then 
return 
end
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(50000)
gg.clearList()
local t2 = {}
for k, v in ipairs(t) do
table.insert(t2, {address = v.address + 0x24, flags = gg.TYPE_DWORD})
table.insert(t2, {address = v.address + 0x34, flags = gg.TYPE_DWORD})
end
gg.addListItems(t2)
t = gg.getListItems()
gg.loadResults(t)
gg.clearList()
gg.refineNumber("600X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
gg.getResults(100)
gg.editAll("1X12", gg.TYPE_DWORD)
gg.clearResults()
gg.toast("🔹🔷1 Mᴏᴏɴ Sᴋɪɴ ✓ 🔷🔹")
end

function a43()
  gg.clearList()
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("214,261,49X12", gg.TYPE_DWORD)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  local t1 = gg.getResults(100000)
  local edit1 = {}
  for k, v in ipairs(t1) do
    table.insert(edit1, {address = v.address - 4, flags = gg.TYPE_DWORD, value = "999999999X4"})
  end
  if #edit1 > 0 then gg.setValues(edit1) end
  gg.clearResults()
  gg.searchNumber("17262X12", gg.TYPE_DWORD)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  local t2 = gg.getResults(9999)
  local edit2 = {}
  for k, v in ipairs(t2) do
  table.insert(edit2, {address = v.address - 4, flags = gg.TYPE_DWORD, value = "999999999X4"})
  end
  if #edit2 > 0 then gg.setValues(edit2) end
  gg.clearResults()
  gg.searchNumber("1125X12", gg.TYPE_DWORD)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  local t3 = gg.getResults(9999)
  local edit3 = {}
  for k, v in ipairs(t3) do
  table.insert(edit3, {address = v.address - 4, flags = gg.TYPE_DWORD, value = "999999999X4"})
  end
  if #edit3 > 0 then gg.setValues(edit3) end
  gg.clearResults()
  gg.clearList()
  local values = gg.prompt({
    "Hᴏᴡ ᴍᴀɴʏ Cᴏɪɴ ʏᴏᴜ Wɪɴ🪙",
    "How ᴍᴀɴʏ Gᴇᴍs ʏᴏᴜ Wɪɴ💎",
    "How ᴍᴀɴʏ Mᴏᴏɴ ʏᴏᴜ Wɪɴ??",
  }, {}, {
    "number",
    "number",
    "number",
  })
  if values == nil then
    return
  end 
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if gg.getResultsCount() < 1 then
    gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
    return
  end
  local base = gg.getResults(100000)
  gg.clearList()
  gg.addListItems(base)
  local t = gg.getListItems()
  gg.removeListItems(t)
  do
    for k, v in ipairs(t) do
      v.address = v.address - 112
      v.flags = gg.TYPE_DWORD
    end 
  end 
  gg.addListItems(t)
  gg.clearResults()
  gg.loadResults(t)
  gg.refineNumber(values[2] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  if gg.getResultsCount() > 0 then
    local res_gems = gg.getResults(10000)
    local edit_gems = {}
    for k, v in ipairs(res_gems) do
      table.insert(edit_gems, {address = v.address - 4, flags = gg.TYPE_DWORD, value = "999999999X4"})
    end
    gg.setValues(edit_gems)
  end
  gg.clearList()
  gg.addListItems(base)
  local t = gg.getListItems()
  gg.removeListItems(t)
  do
    for k, v in ipairs(t) do
      v.address = v.address - 168
      v.flags = gg.TYPE_DWORD
    end 
  end 
  gg.addListItems(t)
  gg.clearResults()
  gg.loadResults(t)
  gg.refineNumber(values[3] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  local moon = {}
  if gg.getResultsCount() > 0 then
    moon = gg.getResults(10000)
    local edit_moon = {}
    for k, v in ipairs(moon) do
      table.insert(edit_moon, {address = v.address - 4, flags = gg.TYPE_DWORD, value = "999999999X4"})
    end
    gg.setValues(edit_moon)
  end
  gg.clearList()
  gg.addListItems(moon)
  local t = gg.getListItems()
  gg.removeListItems(t)
  do
    for k, v in ipairs(t) do
      v.address = v.address + 168
      v.flags = gg.TYPE_DWORD
    end 
  end 
  gg.addListItems(t)
  gg.clearResults()
  gg.loadResults(t)
  gg.refineNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD)
  if gg.getResultsCount() > 0 then
    local res_coins = gg.getResults(10000)
    local edit_coins = {}
    for k, v in ipairs(res_coins) do
      table.insert(edit_coins, {address = v.address - 4, flags = gg.TYPE_DWORD, value = "999999999X4"})
    end
    gg.setValues(edit_coins)
  end
  gg.clearList()
  gg.clearResults()
  gg.toast("🔹🔷Wɪɴ Pʀɪzᴇ Tʀɪʟʟɪᴏɴ Vᴀʟᴜᴇ Cʜᴀɴɢᴇᴅ ✓🔷🔹")
end


function a44()
    gg.clearList()
gg.clearResults()
local values = gg.prompt({
"Pᴜᴛ ʜᴏᴡ ᴍᴜᴄʜ ʏᴏᴜ ʜᴀᴠᴇ Aɴɪᴍᴀʟs, Cʜᴀᴍᴘ, Eɴᴇᴍʏ, Cᴏᴍᴘ",
"Pᴜᴛ ʜᴏᴡ ᴍᴜᴄʜ ʏᴏᴜ want ??",
  }, {}, {
   "number",
"number",
 })
   if values == nil then
   return
  end
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("844506568071681", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
result = gg.getResults(1)
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(500000)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then
gg.removeListItems(t)
end
do
do
for i, i in ipairs(t) do
i.address = i.address + 28
i.flags = gg.TYPE_DWORD
end
end
end
gg.addListItems(t)
copy, t = nil, nil
t = gg.getListItems()
gg.loadResults(t)
gg.clearList()
gg.refineNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
if 1 > gg.getResultsCount() then
gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
gg.clearList()
else
gg.clearList()
local t = gg.getResults(50000000)
gg.addListItems(t)
t = nil
r = gg.getResults(1000000)
local t = {}
do
do
for i, i in ipairs(r) do
t[i] = {
address = i.address + 16,
flags = 4,
gg.addListItems(t)
     }
   t[i] = {
address = i.address + 16,
flags = 4,
  gg.addListItems(t)
    }
end
end
end
t = gg.getListItems()
gg.loadResults(t)
gg.refineNumber(values[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
local cntt = gg.getResultCount()
if cntt < 14 then
local revert = gg.getResults(1000)
gg.editAll(values[2] .. "+X12", gg.TYPE_DWORD)
  gg.toast("🔹🔷 Sᴛᴀᴛɪsᴛɪᴄs Cʜᴀɴɢᴇᴅ ✓🔷🔹")
 else
    gg.toast("⚠️ Kill a Animal ᴀɴᴅ Tʜᴇɴ ᴛᴀᴘ Oɴ 👉 GG Iᴄᴏɴ")
    while true do
       if gg.isVisible(true) then
         gg.setVisible(false)
local cnt = gg.getResultCount()
if cnt == 0 then
gg.alert("⚠️ Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ ᴏʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
break
end
local valuess = gg.prompt({"Refine ʜᴏᴡ ᴍᴜᴄʜ ʏᴏᴜ have now??"}, {}, {"number"})
if not valuess then return end
gg.refineNumber(valuess[1] .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("10000000~2300000000;10000000~2300000000::17", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
if gg.getResultCount() < 14 then
local revert = gg.getResults(1000)
gg.editAll(values[2] .. "+X12", gg.TYPE_DWORD)
gg.toast("🔹🔷 Sᴛᴀᴛɪsᴛɪᴄs Cʜᴀɴɢᴇᴅ ✓🔷🔹")
break 
end
gg.toast("⚠️ Kill a Animal ᴀɴᴅ Tʜᴇɴ ᴛᴀᴘ Oɴ 👉 GG Iᴄᴏɴ")
end
gg.sleep(200)
end
end
end
end

function a45()
gg.clearList()
gg.clearResults()
local values = gg.prompt({
   "What Aɴɪᴍᴀʟ Lᴠʟ you see❓❓",
   "What Aɴɪᴍᴀʟ Lᴠʟ you want❓❓",
  }, {}, {
    "number",
    "number",
  })
  if values == nil then
    return
  end 
    gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("844536632838357", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
  result = gg.getResults(1)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(500)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 0x3E
        i.flags = gg.TYPE_WORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if 1 > gg.getResultsCount() then
    gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
  else
  local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
 v.address = v.address + 0x40
 v.flags = gg.TYPE_WORD
end
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
 v.address = v.address + -0x40
 v.flags = gg.TYPE_WORD
end
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
 v.address = v.address + 0x8
 if copy then v.name = v.name..' #2' end
end
gg.addListItems(t)
t = nil
copy = nil
local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500;200~65500::9", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.getResults(100000)
    gg.editAll(values[2].. "+X6", gg.TYPE_WORD)
   gg.toast("🔹🔷 Aɴɪᴍᴀʟ Lᴠʟ Cʜᴀɴɢᴇ✓🔷🔹")
   gg.clearList()
   gg.clearResults()
  end
end

function EXIT() 
	print("╔═.✵.════════════╗  \n   💖Sᴄʀɪᴘᴛ ʙʏ _IτS _Ꮇꪖժꪖʀꪖ ꨄ-💖  \n                  ༺♡༻  \n  💖Bʏᴇ ʜᴀᴠᴇ ᴀ ɴɪᴄᴇ ᴅᴀʏ💖  \n╚════════════.✵.═╝")
	gg.skipRestoreState()
	gg.setVisible(true)
	os.exit()
	end
	while true do
	if gg.isVisible(true) then
	PUBGMH = 1
	gg.setVisible(false)
	end
	if PUBGMH == 1 then
	HOME()
	end
	end