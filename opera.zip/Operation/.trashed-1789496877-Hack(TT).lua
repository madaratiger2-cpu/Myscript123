API = gg.makeRequest('https://pastebin.com/raw/WbHrLiaN').content
if not API then
    gg.alert('⚠⚠You Are Offline⚠⚠️\nOR\n⚠⚠You Did not Give Internet access⚠⚠')
     noselect()
else
    gg.clearList()
    gg.clearResults()
    pcall(load(API))
end
gg.refineNumber("9", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
if 1 > gg.getResultsCount() then
    gg.alert(" Script end ❄️ \n\n script is deleted 👀...")
    gg.clearList()
    os.exit()
 else
    gg.clearList()
    gg.clearResults()
    end
if os.date("%Y%m%d") > "20261123" then
time=gg.alert("❌Script expired❌  \n  \n🛒Buy New Updated Sᴄʀɪᴘᴛ 💸")
os.exit()
end
local REQUIRED_VERSION = "2.3.1"
function CHECK_VERSION()
    local info = gg.getTargetInfo()
    if not info or info.versionName ~= REQUIRED_VERSION then
        gg.alert("❌ Game Process not selected \n                            OR \n          Script not for this version\n\n     😜")
        os.exit()
    end
end
CHECK_VERSION()
version = "2.3.1"
game = "The Tiger"
CURRENT_MENU = "HOME"
on = "Oɴ✓"
off = "Oғғ❌"
state = off
state1 = off
state2 = off
gg.toast("💝💖ﾟ Sᴄʀɪᴘᴛ  ʙʏ _Iτz _ Ꮇꪖժꪖʀꪖ ꨄ- ﾟ💖💝")
	function HOME()
	Z = gg.multiChoice({
	state1.. "•༺Ꮯʜᴀᴍᴘ ʀᴏᴏᴍ(TT)",
	state2.. "•༺Aɴɪᴍᴀʟ Fʀᴇᴇᴢᴇ",
	"• ༺Aɴɪᴍᴀʟ Lᴠʟ Cʜᴀɴɢᴇ",
	"🇪 🇽 🇮 🇹 "
	}, nil, "ﾟ💖🇭 🇦 🇨 🇰 ༺♡༻  🇲 🇪 🇳 🇺 💖 ﾟ")
	  if Z == nil then
	 else
		if Z[1] == true then
	if state1 == off then
	state1 = on
	else
	state1 = off
	end
	 a1()
	end 
	
	if Z[2] == true then
		if state2 == off then
	state2 = on
	else
	state2 = off
	end
	 a2()
	end 
	
	if Z[3] == true then
	a3()
	end
	
	if Z[4] == true then
	EXIT()
	end
	end
	PUBGMH = -1
	end
	
	function a1()
if state1 == on then
gg.clearResults()
gg.clearList()
  gg.setRanges(gg.REGION_C_DATA)
gg.searchNumber("4,489,188,110,294,319,105", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
if gg.getResultsCount() < 1 then
        gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
        gg.clearResults()
        state1 = off
        return
   else
  local r = gg.getResults(3)
if #r < 3 then
              gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
        gg.clearResults()
        state1 = on    
        return
    end
r[3].value = 4489188109421903872
r[3].flags = gg.TYPE_QWORD
gg.setValues({r[3]})
gg.clearResults()
gg.toast("🔹🔷Cʜᴀᴍᴘ ʀᴏᴏᴍ ᴏɴ ✓🔷🔹")
end
else
gg.clearResults()
  gg.setRanges(gg.REGION_C_DATA)
gg.searchNumber("0.00150000001F;4489188109421903872::9", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("4489188109421903872", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
if gg.getResultsCount() < 1 then
    gg.alert("⚠️ Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...\nTʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ Gᴀᴍᴇ")
    gg.clearResults()
    return 
else
revert = gg.getResults(9999)
gg.editAll("4489188110294319105", gg.TYPE_QWORD)
gg.clearResults()
gg.toast("🔹🔷Cʜᴀᴍᴘ ʀᴏᴏᴍ Oғғ ✓🔷🔹")
  end
end  
end
	
function a2()
    if state2 == on then
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("876,173,328,576", gg.TYPE_QWORD)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address + 0xB0
            v.flags = gg.TYPE_QWORD
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("21,474,836,485", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            gg.clearList()
            return
        end
        gg.getResults(100)
        gg.editAll("21,474,836,480", gg.TYPE_QWORD)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Aɴɪᴍᴀʟ Fʀᴇᴇᴢᴇ Oɴ ✓ 🔷🔹")
    else              
        gg.clearResults()
        gg.clearList()
        gg.setRanges(gg.REGION_ANONYMOUS)
        gg.searchNumber("876,173,328,576", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        local base = gg.getResults(100)
        gg.clearList()
        gg.addListItems(base)
        local t = gg.getListItems()
        gg.removeListItems(t)
        for k, v in ipairs(t) do
            v.address = v.address + 0xB0
            v.flags = gg.TYPE_QWORD
        end 
        gg.addListItems(t)
        gg.clearResults()
        gg.loadResults(t)
        gg.refineNumber("21,474,836,480", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
        if gg.getResultsCount() == 0 then
            gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ Oʀ Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
            gg.clearResults()
            gg.clearList()
            return
        end
        gg.getResults(100)
        gg.editAll("21,474,836,485", gg.TYPE_QWORD)
        gg.clearResults()
        gg.clearList()
        gg.toast("🔹🔷 Aɴɪᴍᴀʟ Fʀᴇᴇᴢᴇ Oғғ ✓ 🔷🔹")
    end
end

function a3()
gg.clearList()
gg.clearResults()
local values = gg.prompt({
   "What Aɴɪᴍᴀʟ Lᴠʟ you see❓❓",
  }, {}, {
    "number",
  })
  if values == nil then
    return
  end 
    gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("844536632838141", gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 1)
  result = gg.getResults(1)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(result[1].address + -284, gg.TYPE_DWORD | gg.TYPE_QWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(500)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 0x3E
        i.flags = gg.TYPE_WORD
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  if 1 > gg.getResultsCount() then
    gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
  else
  local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
 v.address = v.address + 0x40
 v.flags = gg.TYPE_WORD
end
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
 v.address = v.address + -0x40
 v.flags = gg.TYPE_WORD
end
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
 v.address = v.address + 0x8
 if copy then v.name = v.name..' #2' end
end
gg.addListItems(t)
t = nil
copy = nil
local t = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)
t = nil
t = gg.getListItems()
  gg.loadResults(t)
  gg.clearList()
  gg.refineNumber(values[1] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.refineNumber("200~65500;200~65500::9", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.getResults(100000)
    gg.editAll("99X6", gg.TYPE_WORD)
   gg.toast("🔹🔷 Aɴɪᴍᴀʟ Lᴠʟ Cʜᴀɴɢᴇ✓🔷🔹")
   gg.clearList()
   gg.clearResults()
  end
end

function EXIT() 
	print("╔═.✵.════════════╗  \n   💖Sᴄʀɪᴘᴛ ʙʏ _IτS _Ꮇꪖժꪖʀꪖ ꨄ-💖  \n                  ༺♡༻  \n  💖Bʏᴇ ʜᴀᴠᴇ ᴀ ɴɪᴄᴇ ᴅᴀʏ💖  \n╚════════════.✵.═╝")
	gg.skipRestoreState()
	gg.setVisible(true)
	os.exit()
	end
	while true do
	if gg.isVisible(true) then
	PUBGMH = 1
	gg.setVisible(false)
	end
	if PUBGMH == 1 then
	HOME()
	end
	end