gg.clearResults()
  local values = gg.prompt({
        "Hᴏᴡ ᴍᴀɴʏ xᴘ ᴘᴏɪɴᴛ ᴅᴏ ʏᴏᴜ ʜᴀᴠᴇ",
    "Wʜᴀᴛ ɪs ʏᴏᴜʀ ᴄᴜʀʀᴇᴛ ʟᴠʟ",
    "Hᴏᴡ Mᴀɴʏ Xᴘ ᴘᴏɪɴᴛ ʏᴏᴜ ᴡᴀɴᴛ?"
  }, {}, {"number", "number"})
  if values == nil then
    return
  end
  gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber(values[1] .. "~" .. values[1] + 10 .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + 16
        if copy then
          i.name = i.name .. " #2"
        end
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[1] .. "~" .. values[1] + 10 .. "+X12", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  local t = gg.getResults(100000, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.addListItems(t)
  t = nil
  local copy = false
  local t = gg.getListItems()
  if not copy then
    gg.removeListItems(t)
  end
  do
    do
      for i, i in ipairs(t) do
        i.address = i.address + -54
        i.flags = gg.TYPE_WORD
        if copy then
          i.name = i.name .. " #2"
        end
      end
    end
  end
  gg.addListItems(t)
  copy, t = nil, nil
  t = gg.getListItems()
  gg.loadResults(t)
  gg.refineNumber(values[2] .. "+X6", gg.TYPE_WORD, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.clearList()
  if 1 > gg.getResultsCount() then
   gg.alert("⚠️Nᴏ ʀᴇsᴜʟᴛ ғᴏᴜɴᴅ...Tʀʏ ᴀɢᴀɪɴ   Oʀ   Rᴇsᴛᴀʀᴛ ɢᴀᴍᴇ")
    gg.clearList()
  else
    r = gg.getResults(10)
    local t = {}
    do
      do
        for i, i in ipairs(r) do
          t[i] = {
            address = i.address,
            flags = 2,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 8,
            flags = 2,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 38,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 54,
            flags = 4,
            gg.addListItems(t)
          }
          t[i] = {
            address = i.address + 54,
            flags = 4,
            gg.addListItems(t)
          }
        end
      end
    end
    t = gg.getListItems()
    gg.loadResults(t)
    gg.getResults(100000)
    gg.editAll(values[3] .. "+X12", gg.TYPE_DWORD)
    gg.getResults(100000)
        gg.toast("🔹🔷Xᴘ Vᴀʟᴜᴇ Cʜᴀɴɢᴇᴅ ✓🔷🔹")
  end